<template>
<div class="container">
  <div class="row justify-content-center mt-1">
    <div class="text-center text-curiosum font-weight-light"><small>Copyright © 2019 <a class="text-curiosum-light" href="http://curiosumtech.in" target="_blank">Curiosum Tech Pvt. Ltd.</a></small>
    </div>
  </div>
</div>
</template>

<style lang="scss">
.footer {
  padding-bottom: 0.5rem !important;
}
a.text-curiosum {
  color: #4b2722;
}

a.text-curiosum-light {
  color: #ff3c00;
}
.footer-icons {
  margin-left: 0.2rem;
}
</style>