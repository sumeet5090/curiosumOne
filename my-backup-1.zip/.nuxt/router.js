import Vue from 'vue'
import Router from 'vue-router'
import { interopDefault } from './utils'

const _31194f32 = () => interopDefault(import('../pages/faq/index.vue' /* webpackChunkName: "pages/faq/index" */))
const _2d34b753 = () => interopDefault(import('../pages/info/index.vue' /* webpackChunkName: "pages/info/index" */))
const _9bc6c66c = () => interopDefault(import('../pages/manage/index.vue' /* webpackChunkName: "pages/manage/index" */))
const _3be5b03a = () => interopDefault(import('../pages/profile/index.vue' /* webpackChunkName: "pages/profile/index" */))
const _2edf8642 = () => interopDefault(import('../pages/team/index.vue' /* webpackChunkName: "pages/team/index" */))
const _05448b11 = () => interopDefault(import('../pages/profile/update.vue' /* webpackChunkName: "pages/profile/update" */))
const _5674e688 = () => interopDefault(import('../pages/team/create.vue' /* webpackChunkName: "pages/team/create" */))
const _d88a23d4 = () => interopDefault(import('../pages/teams/all.vue' /* webpackChunkName: "pages/teams/all" */))
const _30bb8f72 = () => interopDefault(import('../pages/manage/create/announcement.vue' /* webpackChunkName: "pages/manage/create/announcement" */))
const _70844bf9 = () => interopDefault(import('../pages/manage/create/car.vue' /* webpackChunkName: "pages/manage/create/car" */))
const _68288702 = () => interopDefault(import('../pages/manage/create/event.vue' /* webpackChunkName: "pages/manage/create/event" */))
const _0d1a1ba1 = () => interopDefault(import('../pages/manage/create/livetiming.vue' /* webpackChunkName: "pages/manage/create/livetiming" */))
const _c255a37c = () => interopDefault(import('../pages/manage/create/schedule.vue' /* webpackChunkName: "pages/manage/create/schedule" */))
const _d47fda8a = () => interopDefault(import('../pages/manage/create/static-schedule.vue' /* webpackChunkName: "pages/manage/create/static-schedule" */))
const _4ca811ca = () => interopDefault(import('../pages/manage/create/techupdate.vue' /* webpackChunkName: "pages/manage/create/techupdate" */))
const _c64e82ba = () => interopDefault(import('../pages/manage/delete/announcement.vue' /* webpackChunkName: "pages/manage/delete/announcement" */))
const _0475d26e = () => interopDefault(import('../pages/manage/delete/event.vue' /* webpackChunkName: "pages/manage/delete/event" */))
const _086b6312 = () => interopDefault(import('../pages/manage/delete/livetiming.vue' /* webpackChunkName: "pages/manage/delete/livetiming" */))
const _24126c2c = () => interopDefault(import('../pages/manage/delete/static-schedule.vue' /* webpackChunkName: "pages/manage/delete/static-schedule" */))
const _47f9593b = () => interopDefault(import('../pages/manage/delete/techupdate.vue' /* webpackChunkName: "pages/manage/delete/techupdate" */))
const _79126279 = () => interopDefault(import('../pages/manage/event/teams.vue' /* webpackChunkName: "pages/manage/event/teams" */))
const _5d5e76d4 = () => interopDefault(import('../pages/manage/remove/team-from-event.vue' /* webpackChunkName: "pages/manage/remove/team-from-event" */))
const _5702c3c0 = () => interopDefault(import('../pages/manage/role/add.vue' /* webpackChunkName: "pages/manage/role/add" */))
const _6c4586b5 = () => interopDefault(import('../pages/manage/role/remove.vue' /* webpackChunkName: "pages/manage/role/remove" */))
const _6d64c6c6 = () => interopDefault(import('../pages/manage/update/car.vue' /* webpackChunkName: "pages/manage/update/car" */))
const _1298b80c = () => interopDefault(import('../pages/manage/update/event.vue' /* webpackChunkName: "pages/manage/update/event" */))
const _3b026b95 = () => interopDefault(import('../pages/manage/update/schedule.vue' /* webpackChunkName: "pages/manage/update/schedule" */))
const _9ab47bf0 = () => interopDefault(import('../pages/manage/update/static-schedule.vue' /* webpackChunkName: "pages/manage/update/static-schedule" */))
const _db097346 = () => interopDefault(import('../pages/manage/update/techupdate.vue' /* webpackChunkName: "pages/manage/update/techupdate" */))
const _14abaa94 = () => interopDefault(import('../pages/profile/volunteer/update.vue' /* webpackChunkName: "pages/profile/volunteer/update" */))
const _53330e70 = () => interopDefault(import('../pages/manage/update/announcement/_id.vue' /* webpackChunkName: "pages/manage/update/announcement/_id" */))
const _9ec4aa38 = () => interopDefault(import('../pages/manage/event/_id/teams.vue' /* webpackChunkName: "pages/manage/event/_id/teams" */))
const _2322fa54 = () => interopDefault(import('../pages/event/_id/index.vue' /* webpackChunkName: "pages/event/_id/index" */))
const _304caef7 = () => interopDefault(import('../pages/join/_id.vue' /* webpackChunkName: "pages/join/_id" */))
const _1fb67922 = () => interopDefault(import('../pages/profile/_id.vue' /* webpackChunkName: "pages/profile/_id" */))
const _fbb09fa6 = () => interopDefault(import('../pages/team/_id/index.vue' /* webpackChunkName: "pages/team/_id/index" */))
const _16835d10 = () => interopDefault(import('../pages/event/_id/announcements.vue' /* webpackChunkName: "pages/event/_id/announcements" */))
const _0f039e68 = () => interopDefault(import('../pages/event/_id/forum/index.vue' /* webpackChunkName: "pages/event/_id/forum/index" */))
const _0a1b3e34 = () => interopDefault(import('../pages/event/_id/live-timings.vue' /* webpackChunkName: "pages/event/_id/live-timings" */))
const _7a704c7a = () => interopDefault(import('../pages/event/_id/schedule.vue' /* webpackChunkName: "pages/event/_id/schedule" */))
const _e115b686 = () => interopDefault(import('../pages/event/_id/teams/index.vue' /* webpackChunkName: "pages/event/_id/teams/index" */))
const _827e6082 = () => interopDefault(import('../pages/event/_id/tech-updates.vue' /* webpackChunkName: "pages/event/_id/tech-updates" */))
const _7ca3ffb7 = () => interopDefault(import('../pages/team/_id/members/index.vue' /* webpackChunkName: "pages/team/_id/members/index" */))
const _579f9c98 = () => interopDefault(import('../pages/team/_id/settings.vue' /* webpackChunkName: "pages/team/_id/settings" */))
const _f17aed04 = () => interopDefault(import('../pages/team/_id/update.vue' /* webpackChunkName: "pages/team/_id/update" */))
const _641f63b0 = () => interopDefault(import('../pages/team/_id/captain/change.vue' /* webpackChunkName: "pages/team/_id/captain/change" */))
const _21de8174 = () => interopDefault(import('../pages/team/_id/members/add.vue' /* webpackChunkName: "pages/team/_id/members/add" */))
const _30751c69 = () => interopDefault(import('../pages/event/_id/forum/create/post.vue' /* webpackChunkName: "pages/event/_id/forum/create/post" */))
const _1c4092a8 = () => interopDefault(import('../pages/event/_id/forum/post/_postId/index.vue' /* webpackChunkName: "pages/event/_id/forum/post/_postId/index" */))
const _026ac8b8 = () => interopDefault(import('../pages/event/_id/forum/post/_postId/edit.vue' /* webpackChunkName: "pages/event/_id/forum/post/_postId/edit" */))
const _7ee5b720 = () => interopDefault(import('../pages/index.vue' /* webpackChunkName: "pages/index" */))

Vue.use(Router)

if (process.client) {
  window.history.scrollRestoration = 'manual'
}
const scrollBehavior = function (to, from, savedPosition) {
  // if the returned position is falsy or an empty object,
  // will retain current scroll position.
  let position = false

  // if no children detected
  if (to.matched.length < 2) {
    // scroll to the top of the page
    position = { x: 0, y: 0 }
  } else if (to.matched.some(r => r.components.default.options.scrollToTop)) {
    // if one of the children has scrollToTop option set to true
    position = { x: 0, y: 0 }
  }

  // savedPosition is only available for popstate navigations (back button)
  if (savedPosition) {
    position = savedPosition
  }

  return new Promise((resolve) => {
    // wait for the out transition to complete (if necessary)
    window.$nuxt.$once('triggerScroll', () => {
      // coords will be used if no selector is provided,
      // or if the selector didn't match any element.
      if (to.hash) {
        let hash = to.hash
        // CSS.escape() is not supported with IE and Edge.
        if (typeof window.CSS !== 'undefined' && typeof window.CSS.escape !== 'undefined') {
          hash = '#' + window.CSS.escape(hash.substr(1))
        }
        try {
          if (document.querySelector(hash)) {
            // scroll to anchor by returning the selector
            position = { selector: hash }
          }
        } catch (e) {
          console.warn('Failed to save scroll position. Please add CSS.escape() polyfill (https://github.com/mathiasbynens/CSS.escape).')
        }
      }
      resolve(position)
    })
  })
}

export function createRouter() {
  return new Router({
    mode: 'history',
    base: '/',
    linkActiveClass: 'nuxt-link-active',
    linkExactActiveClass: 'nuxt-link-exact-active',
    scrollBehavior,

    routes: [{
      path: "/faq",
      component: _31194f32,
      name: "faq"
    }, {
      path: "/info",
      component: _2d34b753,
      name: "info"
    }, {
      path: "/manage",
      component: _9bc6c66c,
      name: "manage"
    }, {
      path: "/profile",
      component: _3be5b03a,
      name: "profile"
    }, {
      path: "/team",
      component: _2edf8642,
      name: "team"
    }, {
      path: "/profile/update",
      component: _05448b11,
      name: "profile-update"
    }, {
      path: "/team/create",
      component: _5674e688,
      name: "team-create"
    }, {
      path: "/teams/all",
      component: _d88a23d4,
      name: "teams-all"
    }, {
      path: "/manage/create/announcement",
      component: _30bb8f72,
      name: "manage-create-announcement"
    }, {
      path: "/manage/create/car",
      component: _70844bf9,
      name: "manage-create-car"
    }, {
      path: "/manage/create/event",
      component: _68288702,
      name: "manage-create-event"
    }, {
      path: "/manage/create/livetiming",
      component: _0d1a1ba1,
      name: "manage-create-livetiming"
    }, {
      path: "/manage/create/schedule",
      component: _c255a37c,
      name: "manage-create-schedule"
    }, {
      path: "/manage/create/static-schedule",
      component: _d47fda8a,
      name: "manage-create-static-schedule"
    }, {
      path: "/manage/create/techupdate",
      component: _4ca811ca,
      name: "manage-create-techupdate"
    }, {
      path: "/manage/delete/announcement",
      component: _c64e82ba,
      name: "manage-delete-announcement"
    }, {
      path: "/manage/delete/event",
      component: _0475d26e,
      name: "manage-delete-event"
    }, {
      path: "/manage/delete/livetiming",
      component: _086b6312,
      name: "manage-delete-livetiming"
    }, {
      path: "/manage/delete/static-schedule",
      component: _24126c2c,
      name: "manage-delete-static-schedule"
    }, {
      path: "/manage/delete/techupdate",
      component: _47f9593b,
      name: "manage-delete-techupdate"
    }, {
      path: "/manage/event/teams",
      component: _79126279,
      name: "manage-event-teams"
    }, {
      path: "/manage/remove/team-from-event",
      component: _5d5e76d4,
      name: "manage-remove-team-from-event"
    }, {
      path: "/manage/role/add",
      component: _5702c3c0,
      name: "manage-role-add"
    }, {
      path: "/manage/role/remove",
      component: _6c4586b5,
      name: "manage-role-remove"
    }, {
      path: "/manage/update/car",
      component: _6d64c6c6,
      name: "manage-update-car"
    }, {
      path: "/manage/update/event",
      component: _1298b80c,
      name: "manage-update-event"
    }, {
      path: "/manage/update/schedule",
      component: _3b026b95,
      name: "manage-update-schedule"
    }, {
      path: "/manage/update/static-schedule",
      component: _9ab47bf0,
      name: "manage-update-static-schedule"
    }, {
      path: "/manage/update/techupdate",
      component: _db097346,
      name: "manage-update-techupdate"
    }, {
      path: "/profile/volunteer/update",
      component: _14abaa94,
      name: "profile-volunteer-update"
    }, {
      path: "/manage/update/announcement/:id?",
      component: _53330e70,
      name: "manage-update-announcement-id"
    }, {
      path: "/manage/event/:id?/teams",
      component: _9ec4aa38,
      name: "manage-event-id-teams"
    }, {
      path: "/event/:id?",
      component: _2322fa54,
      name: "event-id"
    }, {
      path: "/join/:id?",
      component: _304caef7,
      name: "join-id"
    }, {
      path: "/profile/:id",
      component: _1fb67922,
      name: "profile-id"
    }, {
      path: "/team/:id",
      component: _fbb09fa6,
      name: "team-id"
    }, {
      path: "/event/:id?/announcements",
      component: _16835d10,
      name: "event-id-announcements"
    }, {
      path: "/event/:id?/forum",
      component: _0f039e68,
      name: "event-id-forum"
    }, {
      path: "/event/:id?/live-timings",
      component: _0a1b3e34,
      name: "event-id-live-timings"
    }, {
      path: "/event/:id?/schedule",
      component: _7a704c7a,
      name: "event-id-schedule"
    }, {
      path: "/event/:id?/teams",
      component: _e115b686,
      name: "event-id-teams"
    }, {
      path: "/event/:id?/tech-updates",
      component: _827e6082,
      name: "event-id-tech-updates"
    }, {
      path: "/team/:id/members",
      component: _7ca3ffb7,
      name: "team-id-members"
    }, {
      path: "/team/:id/settings",
      component: _579f9c98,
      name: "team-id-settings"
    }, {
      path: "/team/:id/update",
      component: _f17aed04,
      name: "team-id-update"
    }, {
      path: "/team/:id/captain/change",
      component: _641f63b0,
      name: "team-id-captain-change"
    }, {
      path: "/team/:id/members/add",
      component: _21de8174,
      name: "team-id-members-add"
    }, {
      path: "/event/:id?/forum/create/post",
      component: _30751c69,
      name: "event-id-forum-create-post"
    }, {
      path: "/event/:id?/forum/post/:postId?",
      component: _1c4092a8,
      name: "event-id-forum-post-postId"
    }, {
      path: "/event/:id?/forum/post/:postId?/edit",
      component: _026ac8b8,
      name: "event-id-forum-post-postId-edit"
    }, {
      path: "/",
      component: _7ee5b720,
      name: "index"
    }],

    fallback: false
  })
}
