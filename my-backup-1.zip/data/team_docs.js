module.exports = [
  {
    team_name: "Team Mirage",
    docs_url: "https://drive.google.com/drive/folders/1hOtCQJELlxn9MPoKItC7FCeeN85RjNmL"
  },
  {
    team_name: "Team Mirage",
    docs_url: "https://drive.google.com/drive/folders/11ezMNuyR6Hy6WtN-iosGNlR9vRCF3Yl1"
  },
  {
    team_name: "Team Roadrunner",
    docs_url: "https://drive.google.com/drive/folders/0BwFPLRdLMaEEUEUxMXBYOElrczQ"
  },
  {
    team_name: "Team Roadrunner",
    docs_url: "https://drive.google.com/drive/folders/18aEkzBYjfFNau3UxO4wsY1XjSW2kHN_t"
  },
  {
    team_name: "Team Roadrunner",
    docs_url: "https://drive.google.com/drive/folders/0BwFPLRdLMaEEdGFHa3FQWU5Bcm8"
  },
  {
    team_name: "Team Roadrunner",
    docs_url: "https://drive.google.com/drive/folders/0B9-h3sgURWVzZU5KOEVKdGtYQ0E"
  },
  {
    team_name: "AGH Racing Team",
    docs_url: "https://drive.google.com/drive/folders/15gAQoKDYHUp4cSslykjAaP4c1Ow-y7QP"
  },
  {
    team_name: "AGH Racing Team",
    docs_url: "https://drive.google.com/drive/folders/1ReYTxPQy9Ke_fQ8I8Ydu5lrALqcR9rjt"
  },
  {
    team_name: "Team Vegadooth Racing",
    docs_url: "https://drive.google.com/drive/folders/1-tkSKMx6iI6H2glJHWaGKrvIQziQuHZe"
  },
  {
    team_name: "Team Vegadooth Racing",
    docs_url: "https://drive.google.com/drive/folders/1G_vfAVrJUWkoP4jn-yItav1lKNhq66hP"
  },
  {
    team_name: "CRCE Formula Racing",
    docs_url: "https://drive.google.com/drive/folders/0BwFPLRdLMaEEbzdJanBxeDRzTjA"
  },
  {
    team_name: "CRCE Formula Racing",
    docs_url: "https://drive.google.com/drive/folders/1ftPD1fRrJV6bQLmvh2ZCsbNOckgAdBFT"
  },
  {
    team_name: "CRCE Formula Racing",
    docs_url: "https://drive.google.com/drive/folders/0BwFPLRdLMaEEMUtOcTNOSHFFWGs"
  },
  {
    team_name: "Kreinto Racing",
    docs_url: "https://drive.google.com/drive/folders/0BwFPLRdLMaEEa0RyTmVwYU14Qmc"
  },
  {
    team_name: "Kreinto Racing",
    docs_url: "https://drive.google.com/drive/folders/0BwFPLRdLMaEEQnRFczFQVGIxdTQ"
  },
  {
    team_name: "Kreinto Racing",
    docs_url: "https://drive.google.com/drive/folders/0B9-h3sgURWVzR05OWl91eFpiRHM"
  },
  {
    team_name: "Infinity Motorsports",
    docs_url: "https://drive.google.com/drive/folders/0BwFPLRdLMaEERThkWlBabmhjOTg"
  },
  {
    team_name: "Infinity Motorsports",
    docs_url: "https://drive.google.com/drive/folders/1IC3KHAkPvHV6PsBGzLUeUpeazMuh6RmX"
  },
  {
    team_name: "Infinity Motorsports",
    docs_url: "https://drive.google.com/drive/folders/0BwFPLRdLMaEEQ05ubWVvWGtZYm8"
  },
  {
    team_name: "Racing Nemos",
    docs_url: "https://drive.google.com/drive/folders/0BwFPLRdLMaEEMDN4eF8tTHQ4LTA"
  },
  {
    team_name: "Racing Nemos",
    docs_url: "https://drive.google.com/drive/folders/0BwFPLRdLMaEEMEg1ZzR1TDNSU3c"
  },
  {
    team_name: "AeroX Motorsports",
    docs_url: "https://drive.google.com/drive/folders/0BwFPLRdLMaEEbkJqWEE2eDU0b2c"
  },
  {
    team_name: "AeroX Motorsports",
    docs_url: "https://drive.google.com/drive/folders/112XcrWjc39UFRGg9aKlYHslyScVPwMC-"
  },
  {
    team_name: "AeroX Motorsports",
    docs_url: "https://drive.google.com/drive/folders/0BwFPLRdLMaEEQjFUbHprZFFyT1U"
  },
  {
    team_name: "Team Rousing",
    docs_url: "https://drive.google.com/drive/folders/1kb0lpGt7kuz1o3PK5Z-IssyETnX9i8eP"
  },
  {
    team_name: "Team Rousing",
    docs_url: "https://drive.google.com/drive/folders/1N5U8HLggjiDFZbShoCqaVDEfqwWgdEIE"
  },
  {
    team_name: "Team Rousing",
    docs_url: "https://drive.google.com/drive/folders/1fqELfkACs1zLvoCJH5I6SX_GncBnMkkL"
  },
  {
    team_name: "Team Rousing",
    docs_url: "https://drive.google.com/drive/folders/1NlATVf--AWH3OctwdTuMWQr_6yzvOsmA"
  },
  {
    team_name: "T-Rex Motorsports",
    docs_url: "https://drive.google.com/drive/folders/10hTlM3kjnwkg6D_oZcInZQIZ1W06X74I"
  },
  {
    team_name: "T-Rex Motorsports",
    docs_url: "https://drive.google.com/drive/folders/1WATew11y9tp8EJk_8h0e7P0SLJgZx65k"
  },
  {
    team_name: "Schnell Racing",
    docs_url: "https://drive.google.com/drive/folders/0BwFPLRdLMaEEOTE3U2R2U3RSaFU"
  },
  {
    team_name: "Schnell Racing",
    docs_url: "https://drive.google.com/drive/folders/1HIEXZgHtoMafU4HLDmRMkHm3lx-GDHMS"
  },
  {
    team_name: "Schnell Racing",
    docs_url: "https://drive.google.com/drive/folders/0B9-h3sgURWVzc2VYajBTQkhzZ1E"
  },
  {
    team_name: "Team Mechnext Racing",
    docs_url: "https://drive.google.com/drive/folders/1QNhCJmhcVVd2zmEIZUxrzjQwLJ9c7QEd"
  },
  {
    team_name: "Team Mechnext Racing",
    docs_url: "https://drive.google.com/drive/folders/1RcN8TLUDay0ti0wkHk0bUSN3WNOhiZH4"
  },
  {
    team_name: "Team Super Ignite",
    docs_url: "https://drive.google.com/drive/folders/1OLaQAEUFlmoJ9OyyK06tQckO0_Bd1VGa"
  },
  {
    team_name: "Team Super Ignite",
    docs_url: "https://drive.google.com/drive/folders/1QhxbEnuq5CiEtBns0t3XmNL8DBnLb7p5"
  },
  {
    team_name: "High Speed Karlsruhe",
    docs_url: "https://drive.google.com/drive/folders/1WovJgQJcSu1-AJ87ctYFul44DVX07h-A"
  },
  {
    team_name: "High Speed Karlsruhe",
    docs_url: "https://drive.google.com/drive/folders/1gL5kAuqK94n_Rdz-4fhpGVnHayoQag_v"
  },
  {
    team_name: "Camber Racing",
    docs_url: "https://drive.google.com/drive/folders/0BwFPLRdLMaEEQUZ2TW1wVE13SWM"
  },
  {
    team_name: "Camber Racing",
    docs_url: "https://drive.google.com/drive/folders/15En7kDVWjHAUtcjRNmCmfOECt_nTLTo3"
  },
  {
    team_name: "Camber Racing",
    docs_url: "https://drive.google.com/drive/folders/0BwFPLRdLMaEEVm4xNHZmRXpYeE0"
  },
  {
    team_name: "Camber Racing",
    docs_url: "https://drive.google.com/drive/folders/0B9-h3sgURWVzcmZYRTBhRmZzMjg"
  },
  {
    team_name: "Indominus Motorsport",
    docs_url: "https://drive.google.com/drive/folders/1Jq3nYPGbfpXjS5wTuX1BQd5lD3_oHhCa"
  },
  {
    team_name: "Indominus Motorsport",
    docs_url: "https://drive.google.com/drive/folders/1BiUU-2zpPth9pSV-xZ7QbydO9s7UK51l"
  },
  {
    team_name: "Manab Racing",
    docs_url: "https://drive.google.com/drive/folders/0BwFPLRdLMaEEVkNvdmd4ZnVBckE"
  },
  {
    team_name: "Manab Racing",
    docs_url: "https://drive.google.com/drive/folders/1TaX5-NYmTqmIOqlJBW_lSGMUyuSb_OrM"
  },
  {
    team_name: "Manab Racing",
    docs_url: "https://drive.google.com/drive/folders/0BwFPLRdLMaEELS13Q09weDczc1k"
  },
  {
    team_name: "Manab Racing",
    docs_url: "https://drive.google.com/drive/folders/0B9-h3sgURWVzek9jeUNESEJGRnM"
  },
  {
    team_name: "Team Octane Racing",
    docs_url: "https://drive.google.com/drive/folders/0BwFPLRdLMaEEVDZTSTdYVGh2QU0"
  },
  {
    team_name: "Team Octane Racing",
    docs_url: "https://drive.google.com/drive/folders/1cOHHRPVtrcw7EEQwEKIF_HXepVrlwvPl"
  },
  {
    team_name: "Team Octane Racing",
    docs_url: "https://drive.google.com/drive/folders/0BwFPLRdLMaEENkZQV0l5ck1hbVU"
  },
  {
    team_name: "Team Octane Racing",
    docs_url: "https://drive.google.com/drive/folders/0B9-h3sgURWVzR0ZxQ3pmQ1VaclU"
  },
  {
    team_name: "Team Accelerons",
    docs_url: "https://drive.google.com/drive/folders/0BwFPLRdLMaEEa25YWnRrVm1hX28"
  },
  {
    team_name: "Team Accelerons",
    docs_url: "https://drive.google.com/drive/folders/1yvCi_5ShtTQqLB5bBPmTBqjgeTtgdXXz"
  },
  {
    team_name: "Team Accelerons",
    docs_url: "https://drive.google.com/drive/folders/0BwFPLRdLMaEEMk9LTTlKWjFnNnM"
  },
  {
    team_name: "Traxion Racing",
    docs_url: "https://drive.google.com/drive/folders/0BwFPLRdLMaEERjUtbVQxT3VleWM"
  },
  {
    team_name: "Traxion Racing",
    docs_url: "https://drive.google.com/drive/folders/1nrRF8vieidToGA00dSCshJTQsp4WZ3z6"
  },
  {
    team_name: "Traxion Racing",
    docs_url: "https://drive.google.com/drive/folders/0BwFPLRdLMaEEZ2JlWGNvNTNUXzg"
  },
  {
    team_name: "Team Lakshya",
    docs_url: "https://drive.google.com/drive/folders/0BwFPLRdLMaEEYURfRmgxLWdRSGs"
  },
  {
    team_name: "Team Lakshya",
    docs_url: "https://drive.google.com/drive/folders/1KBy8v1vqsqxod79sZalSwfmoSZrltlGX"
  },
  {
    team_name: "Team Lakshya",
    docs_url: "https://drive.google.com/drive/folders/0BwFPLRdLMaEEQjlrYmhna0dPRXc"
  },
  {
    team_name: "Team Kratos Racing electric",
    docs_url: "https://drive.google.com/drive/folders/0BwFPLRdLMaEEeDlOUUp5N3BUbFU"
  },
  {
    team_name: "Team Kratos Racing electric",
    docs_url: "https://drive.google.com/drive/folders/0BwFPLRdLMaEERS1MblpRb1JhVUU"
  },
  {
    team_name: "Team Kratos Racing electric",
    docs_url: "https://drive.google.com/drive/folders/0B9-h3sgURWVzVFJTajUzZW5fdnc"
  },
  {
    team_name: "Orion Racing India",
    docs_url: "https://drive.google.com/drive/folders/0BwFPLRdLMaEEaVFTSnluNmFUWE0"
  },
  {
    team_name: "Orion Racing India",
    docs_url: "https://drive.google.com/drive/folders/1TtwhU_BaSrR39Zfx33akf3SMUvZXv-wy"
  },
  {
    team_name: "Orion Racing India",
    docs_url: "https://drive.google.com/drive/folders/0BwFPLRdLMaEES0p6a3ZDUnBDaVk"
  },
  {
    team_name: "SPCE Racing",
    docs_url: "https://drive.google.com/drive/folders/0BwFPLRdLMaEEa0FpblFMMkN4YlE"
  },
  {
    team_name: "SPCE Racing",
    docs_url: "https://drive.google.com/drive/folders/1ViihpHlqBnhT5CNGoCydliOruslqwCh0"
  },
  {
    team_name: "SPCE Racing",
    docs_url: "https://drive.google.com/drive/folders/0BwFPLRdLMaEESUc0ZXBxX3h3M00"
  },
  {
    team_name: "Inspired Karters",
    docs_url: "https://drive.google.com/drive/folders/0BwFPLRdLMaEERTVta0hNYmxIaWM"
  },
  {
    team_name: "Inspired Karters",
    docs_url: "https://drive.google.com/drive/folders/1jd5J9UEleljA9wdhbL8OG3ekQHHH_jdd"
  },
  {
    team_name: "Inspired Karters",
    docs_url: "https://drive.google.com/drive/folders/0BwFPLRdLMaEEWjVlZG1ZSmRLVmM"
  },
  {
    team_name: "Hyperion Racing Team",
    docs_url: "https://drive.google.com/drive/folders/0BwFPLRdLMaEEU1hOX3JLSUEteGM"
  },
  {
    team_name: "Hyperion Racing Team",
    docs_url: "https://drive.google.com/drive/folders/14JnGasLa80Vtz5aLAJQ9zsKmoUQRMaF5"
  },
  {
    team_name: "Pegasus Racing",
    docs_url: "https://drive.google.com/drive/folders/0BwFPLRdLMaEEcFp0aWtTd2J3dkE"
  },
  {
    team_name: "Pegasus Racing",
    docs_url: "https://drive.google.com/drive/folders/1G6zs7UrrFGOioUJ6pvnf701JmO8I-Q89"
  },
  {
    team_name: "Pegasus Racing",
    docs_url: "https://drive.google.com/drive/folders/0BwFPLRdLMaEEOXEyQkJSSXA4Z0k"
  },
  {
    team_name: "Pegasus Racing",
    docs_url: "https://drive.google.com/drive/folders/0B9-h3sgURWVzVlZ4ZTV2bnRiU2M"
  },
  {
    team_name: "Team RGIT Racing",
    docs_url: "https://drive.google.com/drive/folders/1PpRJdOpjzEnyFEXBfaDt-OArZ1Hb8JZ4"
  },
  {
    team_name: "Team RGIT Racing",
    docs_url: "https://drive.google.com/drive/folders/1DnajHCPg69BXbcdlmbgs5pR9dEf3Wl3S"
  },
  {
    team_name: "Wrench Wielders Racing",
    docs_url: "https://drive.google.com/drive/folders/0BwFPLRdLMaEEbUx0TGJmekhqMmc"
  },
  {
    team_name: "Wrench Wielders Racing",
    docs_url: "https://drive.google.com/drive/folders/1bCn91JTOKAOQtvhi5myzlQu6kTlaVTDd"
  },
  {
    team_name: "Wrench Wielders Racing",
    docs_url: "https://drive.google.com/drive/folders/0BwFPLRdLMaEEOTVJSWhiTnkzdUk"
  },
  {
    team_name: "Wrench Wielders Racing",
    docs_url: "https://drive.google.com/drive/folders/0B9-h3sgURWVzLVJ0RWZpaDQ4YlE"
  },
  {
    team_name: "Formula Manipal",
    docs_url: "https://drive.google.com/drive/folders/0BwFPLRdLMaEEQmh1LVl4U2pSYmc"
  },
  {
    team_name: "Formula Manipal",
    docs_url: "https://drive.google.com/drive/folders/1vkVDoXOwFwkgQo3wLhWinxOo7Bw0ikrQ"
  },
  {
    team_name: "Formula Manipal",
    docs_url: "https://drive.google.com/drive/folders/0BwFPLRdLMaEENHZnUXpaODFkOTA"
  },
  {
    team_name: "Formula Manipal",
    docs_url: "https://drive.google.com/drive/folders/0B9-h3sgURWVzVWZib1ctNk5qYW8"
  },
  {
    team_name: "MPSTME Phoenix Racing",
    docs_url: "https://drive.google.com/drive/folders/0BwFPLRdLMaEEdVAyS1VEVDk1T2c"
  },
  {
    team_name: "MPSTME Phoenix Racing",
    docs_url: "https://drive.google.com/drive/folders/1ZRxJZ5JlRStAz_ZSVMMG2NdDRcApIF_Q"
  },
  {
    team_name: "MPSTME Phoenix Racing",
    docs_url: "https://drive.google.com/drive/folders/0B9-h3sgURWVzMlA4a05QcElER2c"
  },
  {
    team_name: "Team Arion",
    docs_url: "https://drive.google.com/drive/folders/1TbHy4rGGGRFVizLCUHqSbeY7Ecr1wWY2"
  },
  {
    team_name: "Team Arion",
    docs_url: "https://drive.google.com/drive/folders/1vt8wUNMARyqTIdCDPJTyNVuCFTx4z5FA"
  },
  {
    team_name: "Team Dhrutaha",
    docs_url: "https://drive.google.com/drive/folders/1YWUD5U8iJ4eLdDy5HDAROvih1NnX8ob6"
  },
  {
    team_name: "Team Dhrutaha",
    docs_url: "https://drive.google.com/drive/folders/11KropcVSzTB6c-GJvig2AiBczvJDPxgP"
  },
  {
    team_name: "Automantra Racing",
    docs_url: "https://drive.google.com/drive/folders/0BwFPLRdLMaEEOUN4ZTNPWUNBeU0"
  },
  {
    team_name: "Automantra Racing",
    docs_url: "https://drive.google.com/drive/folders/1vhis6Vh9yHwqbacRQeMQxBeSHho-uIMf"
  },
  {
    team_name: "Automantra Racing",
    docs_url: "https://drive.google.com/drive/folders/0B9-h3sgURWVzRzhiVmExLWZhZEU"
  },
  {
    team_name: "Illuminati Racers",
    docs_url: "https://drive.google.com/drive/folders/15-jqc1N-QK9dZUiJX5_47FzYllE6nmBC"
  },
  {
    team_name: "Illuminati Racers",
    docs_url: "https://drive.google.com/drive/folders/1WGjYo2tORIpnC_66iwXrj1ePTFrXh4ip"
  },
  {
    team_name: "Team Prahaar Racing",
    docs_url: "https://drive.google.com/drive/folders/0BwFPLRdLMaEENVZaS29IZ1FfbHc"
  },
  {
    team_name: "Team Prahaar Racing",
    docs_url: "https://drive.google.com/drive/folders/1gA4FtDCf8_LzmjT3TONb4kvAsY6i3kBA"
  },
  {
    team_name: "Team Prahaar Racing",
    docs_url: "https://drive.google.com/drive/folders/0B9-h3sgURWVzMUJlc1lTcEFpVnc"
  },
  {
    team_name: "Team Racing Pioneers",
    docs_url: "https://drive.google.com/drive/folders/1lfV_8bJftAzJu0V4iUocB9jTBMh1os97"
  },
  {
    team_name: "Team Racing Pioneers",
    docs_url: "https://drive.google.com/drive/folders/18kipaAmnZETW07UftmfReHEt7y2oUrQX"
  },
  {
    team_name: "NITKRacing",
    docs_url: "https://drive.google.com/drive/folders/1yK6Aeo76GlbAT9JBTWkigZgPQK6YAIWe"
  },
  {
    team_name: "NITKRacing",
    docs_url: "https://drive.google.com/drive/folders/1rP5442yep79WUTnyfACXhRrqYmrgsU4U"
  },
  {
    team_name: "Team Grease Monkeys",
    docs_url: "https://drive.google.com/drive/folders/1bsSeM1OgwRbfuac2ex8OmoF3Ku_nNC-M"
  },
  {
    team_name: "Team Grease Monkeys",
    docs_url: "https://drive.google.com/drive/folders/1YdG-qVL_yluOmpzmdShI57RFQ4Ka-hxZ"
  },
  {
    team_name: "Bullethawk Racing",
    docs_url: "https://drive.google.com/drive/folders/0BwFPLRdLMaEEREdnZHYxbTlpZmc"
  },
  {
    team_name: "Bullethawk Racing",
    docs_url: "https://drive.google.com/drive/folders/1a9Yp1hxvIGwhS7uIr2L-McDQ-_VjWTeZ"
  },
  {
    team_name: "Bullethawk Racing",
    docs_url: "https://drive.google.com/drive/folders/0BwFPLRdLMaEENHhTTlpRRnRxems"
  },
  {
    team_name: "Shaurya Racing",
    docs_url: "https://drive.google.com/drive/folders/0BwFPLRdLMaEEZ0RSZ1NZQ0VVMkE"
  },
  {
    team_name: "Shaurya Racing",
    docs_url: "https://drive.google.com/drive/folders/1Vbi0usmO17SNeVDckchjyMLxkDvOgEm0"
  },
  {
    team_name: "Shaurya Racing",
    docs_url: "https://drive.google.com/drive/folders/0BwFPLRdLMaEEWFY3QV9QM3Rna0U"
  },
  {
    team_name: "Shaurya Racing",
    docs_url: "https://drive.google.com/drive/folders/0B9-h3sgURWVzNkVvRkpxVFlrdVE"
  },
  {
    team_name: "Acceleracers",
    docs_url: "https://drive.google.com/drive/folders/1JSE5VifwsownWOvTt8vEpUOFxLuEk7cc"
  },
  {
    team_name: "Acceleracers",
    docs_url: "https://drive.google.com/drive/folders/1t83b3rLZXinH5x31lGGwau-D9QiLySXP"
  },
  {
    team_name: "Triumphant Racers",
    docs_url: "https://drive.google.com/drive/folders/1bUcPHlz4A1ecgG9RuCWpN2TLQVqskXVY"
  },
  {
    team_name: "Triumphant Racers",
    docs_url: "https://drive.google.com/drive/folders/1l2kPW8SLmdSQTqlc4cBOsH2BHD-lhXyx"
  },
  {
    team_name: "Veloce Racing",
    docs_url: "https://drive.google.com/drive/folders/0BwFPLRdLMaEEOVhldEVNeEVhdmM"
  },
  {
    team_name: "Veloce Racing",
    docs_url: "https://drive.google.com/drive/folders/1vrlpwbdCiyyDYKe0DMTZ2Jwspxu02Ay5"
  },
  {
    team_name: "Veloce Racing",
    docs_url: "https://drive.google.com/drive/folders/0B9-h3sgURWVzdERBYkRFUDNUX1k"
  },
  {
    team_name: "Formula MITE Racing",
    docs_url: "https://drive.google.com/drive/folders/1PP8-LjV-lMUUxxwzld4aJp2cULCQBcwA"
  },
  {
    team_name: "Team Infinity Racers",
    docs_url: "https://drive.google.com/drive/folders/1jBR0CpC0uahv5p2bRM49ON-wvyfzRfQQ"
  },
  {
    team_name: "Team Infinity Racers",
    docs_url: "https://drive.google.com/drive/folders/1MFeqxN49X61MGSlomIDUmfsLreHA1qH6"
  },
  {
    team_name: "Ashwa Racing",
    docs_url: "https://drive.google.com/drive/folders/0BwFPLRdLMaEEWnpvaENtTlFLTUU"
  },
  {
    team_name: "Ashwa Racing",
    docs_url: "https://drive.google.com/drive/folders/1U53zeqKptFcyzglG96jeT3nuZpOuaaKW"
  },
  {
    team_name: "Ashwa Racing",
    docs_url: "https://drive.google.com/drive/folders/0BwFPLRdLMaEELW4yUUg3NHZBX28"
  },
  {
    team_name: "Ashwa Racing",
    docs_url: "https://drive.google.com/drive/folders/0B9-h3sgURWVzMmhUYnFKaTlFU0U"
  },
  {
    team_name: "CITizens Racing",
    docs_url: "https://drive.google.com/drive/folders/1hP096wB_LMu7KIHuFsKtZ3JLEemw8183"
  },
  {
    team_name: "CITizens Racing",
    docs_url: "https://drive.google.com/drive/folders/1FH9uUDUILFHaluL4SdF24oeQkvDsQ7fZ"
  },
  {
    team_name: "Evolution",
    docs_url: "https://drive.google.com/drive/folders/0BwFPLRdLMaEEenh1YW9ZbXJnVlU"
  },
  {
    team_name: "Evolution",
    docs_url: "https://drive.google.com/drive/folders/1pOa3mwuzpMU_UlQzWjZqmEYRFBV8wiKU"
  },
  {
    team_name: "Evolution",
    docs_url: "https://drive.google.com/drive/folders/0B9-h3sgURWVzM1VKcmQtUUpVREk"
  },
  {
    team_name: "Team Corsa",
    docs_url: "https://drive.google.com/drive/folders/0BwFPLRdLMaEER0p5dlAxNkExNzA"
  },
  {
    team_name: "Team Corsa",
    docs_url: "https://drive.google.com/drive/folders/1KwnxZ-dJ1J5_bYI5jOVVXMA5ZEtzFhSU"
  },
  {
    team_name: "Team Corsa",
    docs_url: "https://drive.google.com/drive/folders/0B9-h3sgURWVzdUJRcldYdU5OV0U"
  },
  {
    team_name: "Team Revolution",
    docs_url: "https://drive.google.com/drive/folders/0BwFPLRdLMaEEMFNxdjBJRGgwajQ"
  },
  {
    team_name: "Team Revolution",
    docs_url: "https://drive.google.com/drive/folders/1DH5R2eQqxp4-ErNQ3o9rqtkxyAKz9yum"
  },
  {
    team_name: "Team Revolution",
    docs_url: "https://drive.google.com/drive/folders/0BwFPLRdLMaEEQmtqYnNEck4ycGs"
  },
  {
    team_name: "Velocita Racing",
    docs_url: "https://drive.google.com/drive/folders/1WiUxLifW_SwQP3vSvXI1WFGufXY_0_fc"
  },
  {
    team_name: "Velocita Racing",
    docs_url: "https://drive.google.com/drive/folders/1g0sswvA1LZ32QT72D8EEZEND7z7U9XGO"
  },
  {
    team_name: "Ethan Racing",
    docs_url: "https://drive.google.com/drive/folders/0BwFPLRdLMaEEV3pia3VWSVV3VlE"
  },
  {
    team_name: "Ethan Racing",
    docs_url: "https://drive.google.com/drive/folders/1ho2AGLIFklSM0DLte81gFa6W2PUWTrr4"
  },
  {
    team_name: "Ethan Racing",
    docs_url: "https://drive.google.com/drive/folders/0BwFPLRdLMaEEeV9EemdrWGczbXM"
  },
  {
    team_name: "Ethan Racing",
    docs_url: "https://drive.google.com/drive/folders/0B9-h3sgURWVzdE9EYlJKMVlPZVU"
  },
  {
    team_name: "Team Mechismu",
    docs_url: "https://drive.google.com/drive/folders/0BwFPLRdLMaEEc2szbzB0Y052T00"
  },
  {
    team_name: "Team Mechismu",
    docs_url: "https://drive.google.com/drive/folders/1XKJdShChnxGwfQFT9JWKnFdpmYpgcnSu"
  },
  {
    team_name: "Team Mechismu",
    docs_url: "https://drive.google.com/drive/folders/0B9-h3sgURWVzZGtYT0VKU2hOQ2c"
  },
  {
    team_name: "VeerRacerss",
    docs_url: "https://drive.google.com/drive/folders/0BwFPLRdLMaEEZWRyU3Q2RTVkYXM"
  },
  {
    team_name: "VeerRacerss",
    docs_url: "https://drive.google.com/drive/folders/1F8ASg0xU3xVWd5usvephyNdMXmGI1tDc"
  },
  {
    team_name: "VeerRacerss",
    docs_url: "https://drive.google.com/drive/folders/0BwFPLRdLMaEEa0w5NjlWTmF4R1U"
  },
  {
    team_name: "DIT Motoracing",
    docs_url: "https://drive.google.com/drive/folders/0BwFPLRdLMaEEYmNRcnByQWxpT2c"
  },
  {
    team_name: "DIT Motoracing",
    docs_url: "https://drive.google.com/drive/folders/1C104c7DwO8LPPl76bENKGR4jm0s9B9Kk"
  },
  {
    team_name: "DIT Motoracing",
    docs_url: "https://drive.google.com/drive/folders/0BwFPLRdLMaEEVEJNdnl3UlNwa28"
  },
  {
    team_name: "DIT Motoracing",
    docs_url: "https://drive.google.com/drive/folders/0B9-h3sgURWVzRDNIZXQtWFhVNEE"
  },
  {
    team_name: "Force Ikshvaku",
    docs_url: "https://drive.google.com/drive/folders/0BwFPLRdLMaEEMV9ETkdabERVVFU"
  },
  {
    team_name: "Force Ikshvaku",
    docs_url: "https://drive.google.com/drive/folders/1TnjYmEZeuBPYkx84QvLv77oyf5h4KSHR"
  },
  {
    team_name: "Force Ikshvaku",
    docs_url: "https://drive.google.com/drive/folders/0BwFPLRdLMaEEeklKYnJFNHBJbjg"
  },
  {
    team_name: "GTU Motorsports",
    docs_url: "https://drive.google.com/drive/folders/0BwFPLRdLMaEEQXpFVndLNzBKLTA"
  },
  {
    team_name: "GTU Motorsports",
    docs_url: "https://drive.google.com/drive/folders/1SrKz5ocH1kH2UQZ1uxdQtFFaObm_9HyM"
  },
  {
    team_name: "GTU Motorsports",
    docs_url: "https://drive.google.com/drive/folders/0BwFPLRdLMaEEalU0SWlRWnRSb1U"
  },
  {
    team_name: "GTU Motorsports",
    docs_url: "https://drive.google.com/drive/folders/0B9-h3sgURWVzR0VRWVEyTGF3WFU"
  },
  {
    team_name: "Team Nequit",
    docs_url: "https://drive.google.com/drive/folders/0BwFPLRdLMaEEVDIyYUtIOVpTQXM"
  },
  {
    team_name: "Team Nequit",
    docs_url: "https://drive.google.com/drive/folders/1EM-MnHQIWDv9EMCy-cy0CJUr-Z2TqZ3r"
  },
  {
    team_name: "Team Nequit",
    docs_url: "https://drive.google.com/drive/folders/0BwFPLRdLMaEEWlFoZG5Bem9jM28"
  },
  {
    team_name: "Team KART",
    docs_url: "https://drive.google.com/drive/folders/0BwFPLRdLMaEEUlJjUjJYa211N1k"
  },
  {
    team_name: "Team KART",
    docs_url: "https://drive.google.com/drive/folders/1qDudEaNIMcPBPkjomiR313n6IORYDDmT"
  },
  {
    team_name: "Team KART",
    docs_url: "https://drive.google.com/drive/folders/0B9-h3sgURWVzSGxVT1BXNmh2Vzg"
  },
  {
    team_name: "Resonance Racing",
    docs_url: "https://drive.google.com/drive/folders/0BwFPLRdLMaEEeFQzV0dIeVN1b0U"
  },
  {
    team_name: "Resonance Racing",
    docs_url: "https://drive.google.com/drive/folders/1bBHAWHz0ET1f3aRWpKE_9c7eoPcuImar"
  },
  {
    team_name: "Resonance Racing",
    docs_url: "https://drive.google.com/drive/folders/0BwFPLRdLMaEEV2dzc0E4VC15T28"
  },
  {
    team_name: "Team Srijan",
    docs_url: "https://drive.google.com/drive/folders/0BwFPLRdLMaEEZDlyNVY2aHd0alk"
  },
  {
    team_name: "Team Srijan",
    docs_url: "https://drive.google.com/drive/folders/1o8kO7Dxgik72-CoHayqxKbL365qY5LEh"
  },
  {
    team_name: "Team Srijan",
    docs_url: "https://drive.google.com/drive/folders/0BwFPLRdLMaEELUROalRIWUo4VzA"
  },
  {
    team_name: "Team Srijan",
    docs_url: "https://drive.google.com/drive/folders/0B9-h3sgURWVzRUVPcmRINGtzTXc"
  },
  {
    team_name: "Vishwaracers",
    docs_url: "https://drive.google.com/drive/folders/1c-9V2_nslCNPaOm4Rt-iRpysVJTDi59i"
  },
  {
    team_name: "Vishwaracers",
    docs_url: "https://drive.google.com/drive/folders/1LymP8IBQ3UyEBjiWDHsnNAaplPwPXG1n"
  },
  {
    team_name: "Team Haya Racing",
    docs_url: "https://drive.google.com/drive/folders/0BwFPLRdLMaEEVHc4UkJualJkZjg"
  },
  {
    team_name: "Team Haya Racing",
    docs_url: "https://drive.google.com/drive/folders/1lCSZZUsSv3XWBOv0-HVxRFKte5fJqQsx"
  },
  {
    team_name: "Team Haya Racing",
    docs_url: "https://drive.google.com/drive/folders/0BwFPLRdLMaEEckZEcmhoazJDcE0"
  },
  {
    team_name: "Team Haya Racing",
    docs_url: "https://drive.google.com/drive/folders/0B9-h3sgURWVzZ2s2NUgxaDRzeFk"
  },
  {
    team_name: "Team Fateh",
    docs_url: "https://drive.google.com/drive/folders/0BwFPLRdLMaEESU9XUHNNX25GaTg"
  },
  {
    team_name: "Team Fateh",
    docs_url: "https://drive.google.com/drive/folders/1Fcn52w9X7Va2vo0HgT--qBPfCmBybPi4"
  },
  {
    team_name: "Team Fateh",
    docs_url: "https://drive.google.com/drive/folders/0B9-h3sgURWVzZl9md1ZxbGRCcjQ"
  },
  {
    team_name: "Stallion Motorsport",
    docs_url: "https://drive.google.com/drive/folders/0BwFPLRdLMaEEdG9ScTRRVmJyaUk"
  },
  {
    team_name: "Stallion Motorsport",
    docs_url: "https://drive.google.com/drive/folders/1yHwOCyMl-tdyXnBfQ2syF-4bXdMd1nRO"
  },
  {
    team_name: "Stallion Motorsport",
    docs_url: "https://drive.google.com/drive/folders/0BwFPLRdLMaEEdF83dTZaS2I2SDg"
  },
  {
    team_name: "Stallion Motorsport",
    docs_url: "https://drive.google.com/drive/folders/0B9-h3sgURWVzek1IcHZkNXJvMGM"
  },
  {
    team_name: "DJS Racing electric",
    docs_url: "https://drive.google.com/drive/folders/0BwFPLRdLMaEEQUdDZ3pUOXIwdmM"
  },
  {
    team_name: "DJS Racing electric",
    docs_url: "https://drive.google.com/drive/folders/1Z9oLZstU9_MNeLS3pqB1TiV_dy6vCn4V"
  },
  {
    team_name: "DJS Racing electric",
    docs_url: "https://drive.google.com/drive/folders/0BwFPLRdLMaEEbDNLTEpBT3l3VWs"
  },
  {
    team_name: "DJS Racing electric",
    docs_url: "https://drive.google.com/drive/folders/0B9-h3sgURWVzRkJmRmJUSWRQOFk"
  },
  {
    team_name: "Raftar Formula Racing",
    docs_url: "https://drive.google.com/drive/folders/0BwFPLRdLMaEEVm83ODMtQm5kcmM"
  },
  {
    team_name: "Raftar Formula Racing",
    docs_url: "https://drive.google.com/drive/folders/1JTWOWwyp34ruuSwkSZi1t_dO6e8w6h9W"
  },
  {
    team_name: "Raftar Formula Racing",
    docs_url: "https://drive.google.com/drive/folders/0BwFPLRdLMaEESWdXcDVuUERWRmM"
  },
  {
    team_name: "Raftar Formula Racing",
    docs_url: "https://drive.google.com/drive/folders/0B9-h3sgURWVzaDBrX2VISDRiWG8"
  },
  {
    team_name: "Team Defianz Racing",
    docs_url: "https://drive.google.com/drive/folders/0BwFPLRdLMaEEUW5hUFE2MXVRNEU"
  },
  {
    team_name: "Team Defianz Racing",
    docs_url: "https://drive.google.com/drive/folders/1vAI_vqWfcBLfsk-lqVG53dtX2k-xSR0N"
  },
  {
    team_name: "Team Defianz Racing",
    docs_url: "https://drive.google.com/drive/folders/0BwFPLRdLMaEETm05Mm5YTlUybjg"
  },
  {
    team_name: "Team Chimera",
    docs_url: "https://drive.google.com/drive/folders/17vBjpKBix0nL7-7YwvQq0rDtGVlMUah6"
  },
  {
    team_name: "Team Chimera",
    docs_url: "https://drive.google.com/drive/folders/1GSKsAMQYhlEARCmmYH4Ef5mZvxPeI8EO"
  },
  {
    team_name: "IIT Bombay Racing",
    docs_url: "https://drive.google.com/drive/folders/1Vh6goZgMMFf-YUH-laoEIxCqekOhs8f0"
  },
  {
    team_name: "IIT Bombay Racing",
    docs_url: "https://drive.google.com/drive/folders/1oHVOahBuePgaFwatjXZKjS8c76ANFlaY"
  },
  {
    team_name: "Smokin' Axles",
    docs_url: "https://drive.google.com/drive/folders/1oZVTRhHdpO-oRyj2eR_sSGdgqMjmnWfl"
  },
  {
    team_name: "Smokin' Axles",
    docs_url: "https://drive.google.com/drive/folders/1_psAZMvBs8_hWO-qGRBn_DNP-Ra-LL_e"
  },
  {
    team_name: "Stier Racing",
    docs_url: "https://drive.google.com/drive/folders/1JwlhkXp4A_ZDSE1eL1j9RFs_K08Zk9e5"
  },
  {
    team_name: "Stier Racing",
    docs_url: "https://drive.google.com/drive/folders/1he1SjMsYLAgdnrXK2igEhmox13-m-voP"
  },
  {
    team_name: "E-Boosters",
    docs_url: "https://drive.google.com/drive/folders/1pWndJUR98pLxYT9CMz_zf_EalnhRNCZM"
  },
  {
    team_name: "4ZE Racing",
    docs_url: "https://drive.google.com/drive/folders/1DZ-XZjERWOJSOR-_eD11Jd3Aa1xyfn-S"
  },
  {
    team_name: "4ZE Racing",
    docs_url: "https://drive.google.com/drive/folders/1Majfc3CoCC2Od-JVw0aIA1CtWiJZO_dg"
  },
  {
    team_name: "4ZE Racing",
    docs_url: "https://drive.google.com/drive/folders/1WtV8sU1MgXbMpW_HDlN8yV9HZ3LqwMjy"
  },
  {
    team_name: "Team Kratos Racing electric",
    docs_url: "https://drive.google.com/drive/folders/1gKp-B9tP_kF4t1bYArz82GHh7ZSz6nCv"
  },
  {
    team_name: "Team Kratos Racing electric",
    docs_url: "https://drive.google.com/drive/folders/1N1O-_JFBv-MiJTZyZunrCtQQujTxCo4b"
  },
  {
    team_name: "Valorous Line-Up",
    docs_url: "https://drive.google.com/drive/folders/16_hM9E3_gpG2NTpXhnButMue9Ne6khlr"
  },
  {
    team_name: "Valorous Line-Up",
    docs_url: "https://drive.google.com/drive/folders/18dQOgjDHcGAzmoGkdCGR1ny-zXPGN-lh"
  },
  {
    team_name: "Hertz electric",
    docs_url: "https://drive.google.com/drive/folders/1fQEya0IlyFYY4s-TjqRiLMYUdcu9ESOj"
  },
  {
    team_name: "Hertz electric",
    docs_url: "https://drive.google.com/drive/folders/15uVFP9yMxyqQFc5enQHXzNadZeN4x46s"
  },
  {
    team_name: "VITC Formula electric",
    docs_url: "https://drive.google.com/drive/folders/1mv4PZ28o2lqMeWwJrrGrJfe3IddeRAVr"
  },
  {
    team_name: "VITC Formula electric",
    docs_url: "https://drive.google.com/drive/folders/1bZO31dWoNrVoXzvFRIFkF1cva3d8Laf-"
  },
  {
    team_name: "Team Octavius",
    docs_url: "https://drive.google.com/drive/folders/1LUDfiupWc7E2QKAayOxvHnVW93yml8OY"
  },
  {
    team_name: "Team Octavius",
    docs_url: "https://drive.google.com/drive/folders/1pRlzkel8ktXt4w6ti-_XZFUgZB6-0vvv"
  },
  {
    team_name: "Spark Racing Team",
    docs_url: "https://drive.google.com/drive/folders/13Or81I0NDhkb0uoyBx7Bj428ULDYIMrb"
  },
  {
    team_name: "Spark Racing Team",
    docs_url: "https://drive.google.com/drive/folders/1qFDzaPXpBNYulcaK0z5uqUGj0GfA3_ym"
  },
  {
    team_name: "IIT Roorkee Motorsports",
    docs_url: "https://drive.google.com/drive/folders/1YnBIH5GQ_90wxG5d-_YwGRQbMYlBiwpK"
  },
  {
    team_name: "IIT Roorkee Motorsports",
    docs_url: "https://drive.google.com/drive/folders/13kh8D_TDHQVmJ6aniT6BYpn3WViA-Kqz"
  },
  {
    team_name: "IIT GA Motorsports",
    docs_url: "https://drive.google.com/drive/folders/1W67s6tVjZprgozrHjuD649XGLPaAw0kK"
  },
  {
    team_name: "IIT GA Motorsports",
    docs_url: "https://drive.google.com/drive/folders/1Yes7lvlOHYb9-_4Wx9IIhsGbUTF_7BI-"
  },
  {
    team_name: "G-Tron",
    docs_url: "https://drive.google.com/drive/folders/1uwRu0e38jSVXphnP17OWzlMP74559O-r"
  },
  {
    team_name: "Formula Manipal electric",
    docs_url: "https://drive.google.com/drive/folders/1mlKn3zpiTIcbBbrYcZGZb0_JtYzRKF6C"
  },
  {
    team_name: "Formula Manipal electric",
    docs_url: "https://drive.google.com/drive/folders/1WWYkpMJLb-W-Zl3clz4_028AZcsZEaRs"
  },
  {
    team_name: "DJS Racing electric",
    docs_url: "https://drive.google.com/drive/folders/1gTVheNusGVllWjpPRLUAx3GxerLT8V9H"
  },
  {
    team_name: "DJS Racing electric",
    docs_url: "https://drive.google.com/drive/folders/1b-dfLS08ZlMTZrq0OL3QVhJvpc9FZfvx"
  },
  {
    team_name: "Axlr8r Formula Racing",
    docs_url: "https://drive.google.com/drive/folders/1ftO6hajOW6Mhl54QYoPFTJYWCsJ31gjE"
  },
  {
    team_name: "Axlr8r Formula Racing",
    docs_url: "https://drive.google.com/drive/folders/17mf6vovd4FMfpCFL-Arsm-ncPXGP3SDV"
  }
]