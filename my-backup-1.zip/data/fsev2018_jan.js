module.exports = [
  {
    car_number: "E01",
    team_name: "Ashwa Racing",
    institution_name: "R V College of Engineering",
    category: "electric",
    former_name: "",
    create: false
  },
  {
    car_number: "E02",
    team_name: "Formula Manipal Electric",
    institution_name: "Manipal Academy of Higher Education (formerly Manipal University)",
    category: "electric",
    former_name: "",
    create: false
  },
  {
    car_number: "E03",
    team_name: "ZHCET Formula Racing",
    institution_name: "Zakir Husain College of Engineering and Technology",
    category: "electric",
    former_name: "",
    create: false
  },
  {
    car_number: "E04",
    team_name: "Team Ojas",
    institution_name: "VIT Vellore",
    category: "electric",
    former_name: "",
    create: true
  },
  {
    car_number: "E05",
    team_name: "IIT Bombay Racing",
    institution_name: "Indian Institute of Technology Bombay",
    category: "electric",
    former_name: "",
    create: false
  },
  {
    car_number: "E06",
    team_name: "Automantra Racing",
    institution_name: "Galgotias University",
    category: "electric",
    former_name: "",
    create: false
  },
  {
    car_number: "E07",
    team_name: "4ZE Racing",
    institution_name: "SRM Institute of Science and Technology (formerly SRM University)",
    category: "electric",
    former_name: "",
    create: false
  },
  {
    car_number: "E08",
    team_name: "DJS Racing Electric",
    institution_name: "Dwarkadas J. Sanghvi College of Engineering",
    category: "electric",
    former_name: "",
    create: false
  },
  {
    car_number: "E09",
    team_name: "Amarath Bhishma",
    institution_name: "M.V.S.R. Engineering College",
    category: "electric",
    former_name: "",
    create: true
  },
  {
    car_number: "E10",
    team_name: "Team Chimera",
    institution_name: "RV College of Engineering",
    category: "electric",
    former_name: "",
    create: false
  },
  {
    car_number: "E11",
    team_name: "Orion Racing India",
    institution_name: "K. J. Somaiya College of Engineering",
    category: "electric",
    former_name: "",
    create: false
  },
  {
    car_number: "E12",
    team_name: "Skyline Racing",
    institution_name: "Kalinga Institute of Industrial Technology",
    category: "electric",
    former_name: "",
    create: true
  },
  {
    car_number: "E13",
    team_name: "Axlr8r Formula Racing",
    institution_name: "Indian Institute of Technology Delhi",
    category: "electric",
    former_name: "",
    create: false
  },
  {
    car_number: "E14",
    team_name: "Adhira",
    institution_name: "Indian Institute of Technology Madras",
    category: "electric",
    former_name: "",
    create: true
  },
  {
    car_number: "E15",
    team_name: "DIT Motoracing",
    institution_name: "DIT University",
    category: "electric",
    former_name: "",
    create: false
  },
  {
    car_number: "E16",
    team_name: "VITC Formula Electric",
    institution_name: "VIT Chennai",
    category: "electric",
    former_name: "",
    create: false
  },
  {
    car_number: "E17",
    team_name: "MPSTME Phoenix Racing",
    institution_name: "SVKM's NMIMS Mukesh Patel School of Technology Management & Engineering",
    category: "electric",
    former_name: "MPSTME Motorsports",
    create: false
  },
  {
    car_number: "E18",
    team_name: "Team Kratos Racing Electric",
    institution_name: "Pimpri Chinchwad College of Engineering",
    category: "electric",
    former_name: "",
    create: false
  },
  {
    car_number: "E19",
    team_name: "Team Prahaar Racing",
    institution_name: "Saraswati College of Engineering",
    category: "electric",
    former_name: "",
    create: false
  }
]