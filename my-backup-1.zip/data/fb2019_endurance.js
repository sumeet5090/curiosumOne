module.exports = [
  {
    "car_number": 68,
    "team_name": "Formula Manipal",
    "institution_name": "MAHE",
    "event_name": "Endurance",
    "lap_number": 1,
    "lap_time": 134,
    "driver_initial": "D1"
  },
  {
    "car_number": 68,
    "team_name": "Formula Manipal",
    "institution_name": "MAHE",
    "event_name": "Endurance",
    "lap_number": 2,
    "lap_time": 122,
    "driver_initial": "D1"
  },
  {
    "car_number": 68,
    "team_name": "Formula Manipal",
    "institution_name": "MAHE",
    "event_name": "Endurance",
    "lap_number": 3,
    "lap_time": 123,
    "driver_initial": "D1"
  },
  {
    "car_number": 68,
    "team_name": "Formula Manipal",
    "institution_name": "MAHE",
    "event_name": "Endurance",
    "lap_number": 4,
    "lap_time": 122,
    "driver_initial": "D1"
  },
  {
    "car_number": 68,
    "team_name": "Formula Manipal",
    "institution_name": "MAHE",
    "event_name": "Endurance",
    "lap_number": 5,
    "lap_time": 118,
    "driver_initial": "D1"
  },
  {
    "car_number": 68,
    "team_name": "Formula Manipal",
    "institution_name": "MAHE",
    "event_name": "Endurance",
    "lap_number": 6,
    "lap_time": 120,
    "driver_initial": "D1"
  },
  {
    "car_number": 68,
    "team_name": "Formula Manipal",
    "institution_name": "MAHE",
    "event_name": "Endurance",
    "lap_number": 7,
    "lap_time": 140,
    "driver_initial": "D1"
  },
  {
    "car_number": 68,
    "team_name": "Formula Manipal",
    "institution_name": "MAHE",
    "event_name": "Endurance",
    "lap_number": 8,
    "lap_time": 120,
    "driver_initial": "D1"
  },
  {
    "car_number": 68,
    "team_name": "Formula Manipal",
    "institution_name": "MAHE",
    "event_name": "Endurance",
    "lap_number": 9,
    "lap_time": 121,
    "driver_initial": "D1"
  },
  {
    "car_number": 68,
    "team_name": "Formula Manipal",
    "institution_name": "MAHE",
    "event_name": "Endurance",
    "lap_number": 10,
    "lap_time": 119,
    "driver_initial": "D2"
  },
  {
    "car_number": 68,
    "team_name": "Formula Manipal",
    "institution_name": "MAHE",
    "event_name": "Endurance",
    "lap_number": 11,
    "lap_time": 123,
    "driver_initial": "D2"
  },
  {
    "car_number": 68,
    "team_name": "Formula Manipal",
    "institution_name": "MAHE",
    "event_name": "Endurance",
    "lap_number": 12,
    "lap_time": 125,
    "driver_initial": "D2"
  },
  {
    "car_number": 68,
    "team_name": "Formula Manipal",
    "institution_name": "MAHE",
    "event_name": "Endurance",
    "lap_number": 13,
    "lap_time": 130,
    "driver_initial": "D2"
  },
  {
    "car_number": 68,
    "team_name": "Formula Manipal",
    "institution_name": "MAHE",
    "event_name": "Endurance",
    "lap_number": 14,
    "lap_time": 127,
    "driver_initial": "D2"
  },
  {
    "car_number": 68,
    "team_name": "Formula Manipal",
    "institution_name": "MAHE",
    "event_name": "Endurance",
    "lap_number": 15,
    "lap_time": 131,
    "driver_initial": "D2"
  },
  {
    "car_number": 68,
    "team_name": "Formula Manipal",
    "institution_name": "MAHE",
    "event_name": "Endurance",
    "lap_number": 17,
    "lap_time": 139,
    "driver_initial": "D2"
  },
  {
    "car_number": 68,
    "team_name": "Formula Manipal",
    "institution_name": "MAHE",
    "event_name": "Endurance",
    "lap_number": 18,
    "lap_time": 134,
    "driver_initial": "D2"
  },
  {
    "car_number": 68,
    "team_name": "Formula Manipal",
    "institution_name": "MAHE",
    "event_name": "Endurance",
    "lap_number": 19,
    "lap_time": 131,
    "driver_initial": "D2"
  },
  {
    "car_number": 55,
    "team_name": "Illuminati Racers",
    "institution_name": "LPU",
    "event_name": "Endurance",
    "lap_number": 1,
    "lap_time": 130,
    "driver_initial": "D1"
  },
  {
    "car_number": 55,
    "team_name": "Illuminati Racers",
    "institution_name": "LPU",
    "event_name": "Endurance",
    "lap_number": 2,
    "lap_time": 130,
    "driver_initial": "D1"
  },
  {
    "car_number": 55,
    "team_name": "Illuminati Racers",
    "institution_name": "LPU",
    "event_name": "Endurance",
    "lap_number": 3,
    "lap_time": 126,
    "driver_initial": "D1"
  },
  {
    "car_number": 55,
    "team_name": "Illuminati Racers",
    "institution_name": "LPU",
    "event_name": "Endurance",
    "lap_number": 4,
    "lap_time": 124,
    "driver_initial": "D1"
  },
  {
    "car_number": 55,
    "team_name": "Illuminati Racers",
    "institution_name": "LPU",
    "event_name": "Endurance",
    "lap_number": 5,
    "lap_time": 130,
    "driver_initial": "D1"
  },
  {
    "car_number": 55,
    "team_name": "Illuminati Racers",
    "institution_name": "LPU",
    "event_name": "Endurance",
    "lap_number": 6,
    "lap_time": 123,
    "driver_initial": "D1"
  },
  {
    "car_number": 55,
    "team_name": "Illuminati Racers",
    "institution_name": "LPU",
    "event_name": "Endurance",
    "lap_number": 7,
    "lap_time": 125,
    "driver_initial": "D1"
  },
  {
    "car_number": 55,
    "team_name": "Illuminati Racers",
    "institution_name": "LPU",
    "event_name": "Endurance",
    "lap_number": 8,
    "lap_time": 121,
    "driver_initial": "D1"
  },
  {
    "car_number": 55,
    "team_name": "Illuminati Racers",
    "institution_name": "LPU",
    "event_name": "Endurance",
    "lap_number": 9,
    "lap_time": 120,
    "driver_initial": "D1"
  },
  {
    "car_number": 55,
    "team_name": "Illuminati Racers",
    "institution_name": "LPU",
    "event_name": "Endurance",
    "lap_number": 11,
    "lap_time": 174,
    "driver_initial": "D2"
  },
  {
    "car_number": 55,
    "team_name": "Illuminati Racers",
    "institution_name": "LPU",
    "event_name": "Endurance",
    "lap_number": 12,
    "lap_time": 142,
    "driver_initial": "D2"
  },
  {
    "car_number": 55,
    "team_name": "Illuminati Racers",
    "institution_name": "LPU",
    "event_name": "Endurance",
    "lap_number": 13,
    "lap_time": 144,
    "driver_initial": "D2"
  },
  {
    "car_number": 55,
    "team_name": "Illuminati Racers",
    "institution_name": "LPU",
    "event_name": "Endurance",
    "lap_number": 14,
    "lap_time": 147,
    "driver_initial": "D2"
  },
  {
    "car_number": 43,
    "team_name": "Accelearcers",
    "institution_name": "MIT-WPU",
    "event_name": "Endurance",
    "lap_number": 1,
    "lap_time": 106,
    "driver_initial": "D1"
  },
  {
    "car_number": 43,
    "team_name": "Accelearcers",
    "institution_name": "MIT-WPU",
    "event_name": "Endurance",
    "lap_number": 2,
    "lap_time": 105,
    "driver_initial": "D1"
  },
  {
    "car_number": 43,
    "team_name": "Accelearcers",
    "institution_name": "MIT-WPU",
    "event_name": "Endurance",
    "lap_number": 3,
    "lap_time": 114,
    "driver_initial": "D1"
  },
  {
    "car_number": 43,
    "team_name": "Accelearcers",
    "institution_name": "MIT-WPU",
    "event_name": "Endurance",
    "lap_number": 4,
    "lap_time": 108,
    "driver_initial": "D1"
  },
  {
    "car_number": 43,
    "team_name": "Accelearcers",
    "institution_name": "MIT-WPU",
    "event_name": "Endurance",
    "lap_number": 5,
    "lap_time": 105,
    "driver_initial": "D1"
  },
  {
    "car_number": 43,
    "team_name": "Accelearcers",
    "institution_name": "MIT-WPU",
    "event_name": "Endurance",
    "lap_number": 6,
    "lap_time": 101,
    "driver_initial": "D1"
  },
  {
    "car_number": 43,
    "team_name": "Accelearcers",
    "institution_name": "MIT-WPU",
    "event_name": "Endurance",
    "lap_number": 7,
    "lap_time": 101,
    "driver_initial": "D1"
  },
  {
    "car_number": 43,
    "team_name": "Accelearcers",
    "institution_name": "MIT-WPU",
    "event_name": "Endurance",
    "lap_number": 8,
    "lap_time": 108,
    "driver_initial": "D1"
  },
  {
    "car_number": 43,
    "team_name": "Accelearcers",
    "institution_name": "MIT-WPU",
    "event_name": "Endurance",
    "lap_number": 9,
    "lap_time": 118,
    "driver_initial": "D1"
  },
  {
    "car_number": 43,
    "team_name": "Accelearcers",
    "institution_name": "MIT-WPU",
    "event_name": "Endurance",
    "lap_number": 11,
    "lap_time": 122,
    "driver_initial": "D2"
  },
  {
    "car_number": 43,
    "team_name": "Accelearcers",
    "institution_name": "MIT-WPU",
    "event_name": "Endurance",
    "lap_number": 12,
    "lap_time": 113,
    "driver_initial": "D2"
  },
  {
    "car_number": 43,
    "team_name": "Accelearcers",
    "institution_name": "MIT-WPU",
    "event_name": "Endurance",
    "lap_number": 13,
    "lap_time": 107,
    "driver_initial": "D2"
  },
  {
    "car_number": 43,
    "team_name": "Accelearcers",
    "institution_name": "MIT-WPU",
    "event_name": "Endurance",
    "lap_number": 14,
    "lap_time": 107,
    "driver_initial": "D2"
  },
  {
    "car_number": 43,
    "team_name": "Accelearcers",
    "institution_name": "MIT-WPU",
    "event_name": "Endurance",
    "lap_number": 15,
    "lap_time": 129,
    "driver_initial": "D2"
  },
  {
    "car_number": 43,
    "team_name": "Accelearcers",
    "institution_name": "MIT-WPU",
    "event_name": "Endurance",
    "lap_number": 16,
    "lap_time": 127,
    "driver_initial": "D2"
  },
  {
    "car_number": 43,
    "team_name": "Accelearcers",
    "institution_name": "MIT-WPU",
    "event_name": "Endurance",
    "lap_number": 17,
    "lap_time": 104,
    "driver_initial": "D2"
  },
  {
    "car_number": 43,
    "team_name": "Accelearcers",
    "institution_name": "MIT-WPU",
    "event_name": "Endurance",
    "lap_number": 18,
    "lap_time": 112,
    "driver_initial": "D2"
  },
  {
    "car_number": 43,
    "team_name": "Accelearcers",
    "institution_name": "MIT-WPU",
    "event_name": "Endurance",
    "lap_number": 19,
    "lap_time": 121,
    "driver_initial": "D2"
  },
  {
    "car_number": 3,
    "team_name": "Raftar Formula Racing",
    "institution_name": "IIT Madras",
    "event_name": "Endurance",
    "lap_number": 1,
    "lap_time": 124,
    "driver_initial": "D1"
  },
  {
    "car_number": 3,
    "team_name": "Raftar Formula Racing",
    "institution_name": "IIT Madras",
    "event_name": "Endurance",
    "lap_number": 2,
    "lap_time": 107,
    "driver_initial": "D1"
  },
  {
    "car_number": 3,
    "team_name": "Raftar Formula Racing",
    "institution_name": "IIT Madras",
    "event_name": "Endurance",
    "lap_number": 3,
    "lap_time": 107,
    "driver_initial": "D1"
  },
  {
    "car_number": 3,
    "team_name": "Raftar Formula Racing",
    "institution_name": "IIT Madras",
    "event_name": "Endurance",
    "lap_number": 4,
    "lap_time": 106,
    "driver_initial": "D1"
  },
  {
    "car_number": 3,
    "team_name": "Raftar Formula Racing",
    "institution_name": "IIT Madras",
    "event_name": "Endurance",
    "lap_number": 5,
    "lap_time": 107,
    "driver_initial": "D1"
  },
  {
    "car_number": 3,
    "team_name": "Raftar Formula Racing",
    "institution_name": "IIT Madras",
    "event_name": "Endurance",
    "lap_number": 6,
    "lap_time": 103,
    "driver_initial": "D1"
  },
  {
    "car_number": 3,
    "team_name": "Raftar Formula Racing",
    "institution_name": "IIT Madras",
    "event_name": "Endurance",
    "lap_number": 7,
    "lap_time": 104,
    "driver_initial": "D1"
  },
  {
    "car_number": 3,
    "team_name": "Raftar Formula Racing",
    "institution_name": "IIT Madras",
    "event_name": "Endurance",
    "lap_number": 8,
    "lap_time": 104,
    "driver_initial": "D1"
  },
  {
    "car_number": 3,
    "team_name": "Raftar Formula Racing",
    "institution_name": "IIT Madras",
    "event_name": "Endurance",
    "lap_number": 9,
    "lap_time": 104,
    "driver_initial": "D1"
  },
  {
    "car_number": 2,
    "team_name": "Team Defianz Racing",
    "institution_name": "DTU",
    "event_name": "Endurance",
    "lap_number": 2,
    "lap_time": 130,
    "driver_initial": "D1"
  },
  {
    "car_number": 2,
    "team_name": "Team Defianz Racing",
    "institution_name": "DTU",
    "event_name": "Endurance",
    "lap_number": 3,
    "lap_time": 130,
    "driver_initial": "D1"
  },
  {
    "car_number": 2,
    "team_name": "Team Defianz Racing",
    "institution_name": "DTU",
    "event_name": "Endurance",
    "lap_number": 4,
    "lap_time": 143,
    "driver_initial": "D1"
  },
  {
    "car_number": 2,
    "team_name": "Team Defianz Racing",
    "institution_name": "DTU",
    "event_name": "Endurance",
    "lap_number": 5,
    "lap_time": 124,
    "driver_initial": "D1"
  },
  {
    "car_number": 2,
    "team_name": "Team Defianz Racing",
    "institution_name": "DTU",
    "event_name": "Endurance",
    "lap_number": 6,
    "lap_time": 111,
    "driver_initial": "D1"
  },
  {
    "car_number": 2,
    "team_name": "Team Defianz Racing",
    "institution_name": "DTU",
    "event_name": "Endurance",
    "lap_number": 7,
    "lap_time": 108,
    "driver_initial": "D1"
  },
  {
    "car_number": 2,
    "team_name": "Team Defianz Racing",
    "institution_name": "DTU",
    "event_name": "Endurance",
    "lap_number": 8,
    "lap_time": 152,
    "driver_initial": "D1"
  },
  {
    "car_number": 2,
    "team_name": "Team Defianz Racing",
    "institution_name": "DTU",
    "event_name": "Endurance",
    "lap_number": 9,
    "lap_time": 135,
    "driver_initial": "D1"
  },
  {
    "car_number": 44,
    "team_name": "Shaurya Racing",
    "institution_name": "VIT Chennai",
    "event_name": "Endurance",
    "lap_number": 1,
    "lap_time": 121,
    "driver_initial": "D1"
  },
  {
    "car_number": 44,
    "team_name": "Shaurya Racing",
    "institution_name": "VIT Chennai",
    "event_name": "Endurance",
    "lap_number": 2,
    "lap_time": 142,
    "driver_initial": "D1"
  },
  {
    "car_number": 44,
    "team_name": "Shaurya Racing",
    "institution_name": "VIT Chennai",
    "event_name": "Endurance",
    "lap_number": 3,
    "lap_time": 114,
    "driver_initial": "D1"
  },
  {
    "car_number": 44,
    "team_name": "Shaurya Racing",
    "institution_name": "VIT Chennai",
    "event_name": "Endurance",
    "lap_number": 4,
    "lap_time": 166,
    "driver_initial": "D1"
  },
  {
    "car_number": 44,
    "team_name": "Shaurya Racing",
    "institution_name": "VIT Chennai",
    "event_name": "Endurance",
    "lap_number": 5,
    "lap_time": 133,
    "driver_initial": "D1"
  },
  {
    "car_number": 44,
    "team_name": "Shaurya Racing",
    "institution_name": "VIT Chennai",
    "event_name": "Endurance",
    "lap_number": 6,
    "lap_time": 134,
    "driver_initial": "D1"
  },
  {
    "car_number": 44,
    "team_name": "Shaurya Racing",
    "institution_name": "VIT Chennai",
    "event_name": "Endurance",
    "lap_number": 7,
    "lap_time": 123,
    "driver_initial": "D1"
  },
  {
    "car_number": 44,
    "team_name": "Shaurya Racing",
    "institution_name": "VIT Chennai",
    "event_name": "Endurance",
    "lap_number": 8,
    "lap_time": 147,
    "driver_initial": "D1"
  },
  {
    "car_number": 44,
    "team_name": "Shaurya Racing",
    "institution_name": "VIT Chennai",
    "event_name": "Endurance",
    "lap_number": 9,
    "lap_time": 119,
    "driver_initial": "D1"
  },
  {
    "car_number": 44,
    "team_name": "Shaurya Racing",
    "institution_name": "VIT Chennai",
    "event_name": "Endurance",
    "lap_number": 10,
    "lap_time": 135,
    "driver_initial": "D2"
  },
  {
    "car_number": 44,
    "team_name": "Shaurya Racing",
    "institution_name": "VIT Chennai",
    "event_name": "Endurance",
    "lap_number": 11,
    "lap_time": 145,
    "driver_initial": "D2"
  },
  {
    "car_number": 44,
    "team_name": "Shaurya Racing",
    "institution_name": "VIT Chennai",
    "event_name": "Endurance",
    "lap_number": 12,
    "lap_time": 144,
    "driver_initial": "D2"
  },
  {
    "car_number": 44,
    "team_name": "Shaurya Racing",
    "institution_name": "VIT Chennai",
    "event_name": "Endurance",
    "lap_number": 13,
    "lap_time": 136,
    "driver_initial": "D2"
  },
  {
    "car_number": 44,
    "team_name": "Shaurya Racing",
    "institution_name": "VIT Chennai",
    "event_name": "Endurance",
    "lap_number": 14,
    "lap_time": 133,
    "driver_initial": "D2"
  },
  {
    "car_number": 44,
    "team_name": "Shaurya Racing",
    "institution_name": "VIT Chennai",
    "event_name": "Endurance",
    "lap_number": 15,
    "lap_time": 135,
    "driver_initial": "D2"
  },
  {
    "car_number": 44,
    "team_name": "Shaurya Racing",
    "institution_name": "VIT Chennai",
    "event_name": "Endurance",
    "lap_number": 16,
    "lap_time": 135,
    "driver_initial": "D2"
  },
  {
    "car_number": 44,
    "team_name": "Shaurya Racing",
    "institution_name": "VIT Chennai",
    "event_name": "Endurance",
    "lap_number": 17,
    "lap_time": 136,
    "driver_initial": "D2"
  },
  {
    "car_number": 44,
    "team_name": "Shaurya Racing",
    "institution_name": "VIT Chennai",
    "event_name": "Endurance",
    "lap_number": 18,
    "lap_time": 235,
    "driver_initial": "D2"
  },
  {
    "car_number": 7,
    "team_name": "Camber Racing",
    "institution_name": "SRM IST",
    "event_name": "Endurance",
    "lap_number": 1,
    "lap_time": 154,
    "driver_initial": "D1"
  },
  {
    "car_number": 7,
    "team_name": "Camber Racing",
    "institution_name": "SRM IST",
    "event_name": "Endurance",
    "lap_number": 2,
    "lap_time": 149,
    "driver_initial": "D1"
  },
  {
    "car_number": 7,
    "team_name": "Camber Racing",
    "institution_name": "SRM IST",
    "event_name": "Endurance",
    "lap_number": 3,
    "lap_time": 126,
    "driver_initial": "D1"
  },
  {
    "car_number": 7,
    "team_name": "Camber Racing",
    "institution_name": "SRM IST",
    "event_name": "Endurance",
    "lap_number": 4,
    "lap_time": 150,
    "driver_initial": "D1"
  },
  {
    "car_number": 7,
    "team_name": "Camber Racing",
    "institution_name": "SRM IST",
    "event_name": "Endurance",
    "lap_number": 5,
    "lap_time": 135,
    "driver_initial": "D1"
  },
  {
    "car_number": 7,
    "team_name": "Camber Racing",
    "institution_name": "SRM IST",
    "event_name": "Endurance",
    "lap_number": 6,
    "lap_time": 145,
    "driver_initial": "D1"
  },
  {
    "car_number": 7,
    "team_name": "Camber Racing",
    "institution_name": "SRM IST",
    "event_name": "Endurance",
    "lap_number": 7,
    "lap_time": 147,
    "driver_initial": "D1"
  },
  {
    "car_number": 7,
    "team_name": "Camber Racing",
    "institution_name": "SRM IST",
    "event_name": "Endurance",
    "lap_number": 8,
    "lap_time": 172,
    "driver_initial": "D1"
  },
  {
    "car_number": 7,
    "team_name": "Camber Racing",
    "institution_name": "SRM IST",
    "event_name": "Endurance",
    "lap_number": 9,
    "lap_time": 182,
    "driver_initial": "D1"
  },
  {
    "car_number": 7,
    "team_name": "Camber Racing",
    "institution_name": "SRM IST",
    "event_name": "Endurance",
    "lap_number": 10,
    "lap_time": 146,
    "driver_initial": "D2"
  },
  {
    "car_number": 7,
    "team_name": "Camber Racing",
    "institution_name": "SRM IST",
    "event_name": "Endurance",
    "lap_number": 12,
    "lap_time": 140,
    "driver_initial": "D2"
  },
  {
    "car_number": 7,
    "team_name": "Camber Racing",
    "institution_name": "SRM IST",
    "event_name": "Endurance",
    "lap_number": 13,
    "lap_time": 155,
    "driver_initial": "D2"
  },
  {
    "car_number": 7,
    "team_name": "Camber Racing",
    "institution_name": "SRM IST",
    "event_name": "Endurance",
    "lap_number": 14,
    "lap_time": 155,
    "driver_initial": "D2"
  },
  {
    "car_number": 7,
    "team_name": "Camber Racing",
    "institution_name": "SRM IST",
    "event_name": "Endurance",
    "lap_number": 15,
    "lap_time": 148,
    "driver_initial": "D2"
  },
  {
    "car_number": 71,
    "team_name": "Pegasus Racing",
    "institution_name": "PSG College of Technology",
    "event_name": "Endurance",
    "lap_number": 1,
    "lap_time": 155,
    "driver_initial": "D1"
  },
  {
    "car_number": 71,
    "team_name": "Pegasus Racing",
    "institution_name": "PSG College of Technology",
    "event_name": "Endurance",
    "lap_number": 2,
    "lap_time": 128,
    "driver_initial": "D1"
  },
  {
    "car_number": 71,
    "team_name": "Pegasus Racing",
    "institution_name": "PSG College of Technology",
    "event_name": "Endurance",
    "lap_number": 3,
    "lap_time": 127,
    "driver_initial": "D1"
  },
  {
    "car_number": 71,
    "team_name": "Pegasus Racing",
    "institution_name": "PSG College of Technology",
    "event_name": "Endurance",
    "lap_number": 4,
    "lap_time": 129,
    "driver_initial": "D1"
  },
  {
    "car_number": 71,
    "team_name": "Pegasus Racing",
    "institution_name": "PSG College of Technology",
    "event_name": "Endurance",
    "lap_number": 5,
    "lap_time": 126,
    "driver_initial": "D1"
  },
  {
    "car_number": 71,
    "team_name": "Pegasus Racing",
    "institution_name": "PSG College of Technology",
    "event_name": "Endurance",
    "lap_number": 6,
    "lap_time": 136,
    "driver_initial": "D1"
  },
  {
    "car_number": 71,
    "team_name": "Pegasus Racing",
    "institution_name": "PSG College of Technology",
    "event_name": "Endurance",
    "lap_number": 7,
    "lap_time": 131,
    "driver_initial": "D1"
  },
  {
    "car_number": 71,
    "team_name": "Pegasus Racing",
    "institution_name": "PSG College of Technology",
    "event_name": "Endurance",
    "lap_number": 8,
    "lap_time": 124,
    "driver_initial": "D1"
  },
  {
    "car_number": 71,
    "team_name": "Pegasus Racing",
    "institution_name": "PSG College of Technology",
    "event_name": "Endurance",
    "lap_number": 9,
    "lap_time": 134,
    "driver_initial": "D1"
  },
  {
    "car_number": 71,
    "team_name": "Pegasus Racing",
    "institution_name": "PSG College of Technology",
    "event_name": "Endurance",
    "lap_number": 10,
    "lap_time": 115,
    "driver_initial": "D2"
  },
  {
    "car_number": 71,
    "team_name": "Pegasus Racing",
    "institution_name": "PSG College of Technology",
    "event_name": "Endurance",
    "lap_number": 11,
    "lap_time": 119,
    "driver_initial": "D2"
  },
  {
    "car_number": 71,
    "team_name": "Pegasus Racing",
    "institution_name": "PSG College of Technology",
    "event_name": "Endurance",
    "lap_number": 12,
    "lap_time": 121,
    "driver_initial": "D2"
  },
  {
    "car_number": 71,
    "team_name": "Pegasus Racing",
    "institution_name": "PSG College of Technology",
    "event_name": "Endurance",
    "lap_number": 13,
    "lap_time": 125,
    "driver_initial": "D2"
  },
  {
    "car_number": 71,
    "team_name": "Pegasus Racing",
    "institution_name": "PSG College of Technology",
    "event_name": "Endurance",
    "lap_number": 14,
    "lap_time": 126,
    "driver_initial": "D2"
  },
  {
    "car_number": 71,
    "team_name": "Pegasus Racing",
    "institution_name": "PSG College of Technology",
    "event_name": "Endurance",
    "lap_number": 15,
    "lap_time": 124,
    "driver_initial": "D2"
  },
  {
    "car_number": 71,
    "team_name": "Pegasus Racing",
    "institution_name": "PSG College of Technology",
    "event_name": "Endurance",
    "lap_number": 16,
    "lap_time": 130,
    "driver_initial": "D2"
  },
  {
    "car_number": 71,
    "team_name": "Pegasus Racing",
    "institution_name": "PSG College of Technology",
    "event_name": "Endurance",
    "lap_number": 17,
    "lap_time": 139,
    "driver_initial": "D2"
  },
  {
    "car_number": 71,
    "team_name": "Pegasus Racing",
    "institution_name": "PSG College of Technology",
    "event_name": "Endurance",
    "lap_number": 18,
    "lap_time": 128,
    "driver_initial": "D2"
  },
  {
    "car_number": 23,
    "team_name": "SPCE Racing",
    "institution_name": "SPCE Mumbai",
    "event_name": "Endurance",
    "lap_number": 1,
    "lap_time": 135,
    "driver_initial": "D1"
  },
  {
    "car_number": 23,
    "team_name": "SPCE Racing",
    "institution_name": "SPCE Mumbai",
    "event_name": "Endurance",
    "lap_number": 2,
    "lap_time": 136,
    "driver_initial": "D1"
  },
  {
    "car_number": 23,
    "team_name": "SPCE Racing",
    "institution_name": "SPCE Mumbai",
    "event_name": "Endurance",
    "lap_number": 3,
    "lap_time": 119,
    "driver_initial": "D1"
  },
  {
    "car_number": 23,
    "team_name": "SPCE Racing",
    "institution_name": "SPCE Mumbai",
    "event_name": "Endurance",
    "lap_number": 4,
    "lap_time": 117,
    "driver_initial": "D1"
  },
  {
    "car_number": 23,
    "team_name": "SPCE Racing",
    "institution_name": "SPCE Mumbai",
    "event_name": "Endurance",
    "lap_number": 5,
    "lap_time": 118,
    "driver_initial": "D1"
  },
  {
    "car_number": 23,
    "team_name": "SPCE Racing",
    "institution_name": "SPCE Mumbai",
    "event_name": "Endurance",
    "lap_number": 6,
    "lap_time": 117,
    "driver_initial": "D1"
  },
  {
    "car_number": 23,
    "team_name": "SPCE Racing",
    "institution_name": "SPCE Mumbai",
    "event_name": "Endurance",
    "lap_number": 7,
    "lap_time": 119,
    "driver_initial": "D1"
  },
  {
    "car_number": 23,
    "team_name": "SPCE Racing",
    "institution_name": "SPCE Mumbai",
    "event_name": "Endurance",
    "lap_number": 8,
    "lap_time": 116,
    "driver_initial": "D1"
  },
  {
    "car_number": 23,
    "team_name": "SPCE Racing",
    "institution_name": "SPCE Mumbai",
    "event_name": "Endurance",
    "lap_number": 9,
    "lap_time": 116,
    "driver_initial": "D1"
  },
  {
    "car_number": 5,
    "team_name": "Stallion Motorsport",
    "institution_name": "SKNCOE",
    "event_name": "Endurance",
    "lap_number": 1,
    "lap_time": 118,
    "driver_initial": "D1"
  },
  {
    "car_number": 5,
    "team_name": "Stallion Motorsport",
    "institution_name": "SKNCOE",
    "event_name": "Endurance",
    "lap_number": 2,
    "lap_time": 112,
    "driver_initial": "D1"
  },
  {
    "car_number": 5,
    "team_name": "Stallion Motorsport",
    "institution_name": "SKNCOE",
    "event_name": "Endurance",
    "lap_number": 3,
    "lap_time": 117,
    "driver_initial": "D1"
  },
  {
    "car_number": 5,
    "team_name": "Stallion Motorsport",
    "institution_name": "SKNCOE",
    "event_name": "Endurance",
    "lap_number": 4,
    "lap_time": 119,
    "driver_initial": "D1"
  },
  {
    "car_number": 5,
    "team_name": "Stallion Motorsport",
    "institution_name": "SKNCOE",
    "event_name": "Endurance",
    "lap_number": 5,
    "lap_time": 123,
    "driver_initial": "D1"
  },
  {
    "car_number": 5,
    "team_name": "Stallion Motorsport",
    "institution_name": "SKNCOE",
    "event_name": "Endurance",
    "lap_number": 6,
    "lap_time": 130,
    "driver_initial": "D1"
  },
  {
    "car_number": 5,
    "team_name": "Stallion Motorsport",
    "institution_name": "SKNCOE",
    "event_name": "Endurance",
    "lap_number": 7,
    "lap_time": 125,
    "driver_initial": "D1"
  },
  {
    "car_number": 5,
    "team_name": "Stallion Motorsport",
    "institution_name": "SKNCOE",
    "event_name": "Endurance",
    "lap_number": 8,
    "lap_time": 130,
    "driver_initial": "D1"
  },
  {
    "car_number": 5,
    "team_name": "Stallion Motorsport",
    "institution_name": "SKNCOE",
    "event_name": "Endurance",
    "lap_number": 9,
    "lap_time": 134,
    "driver_initial": "D1"
  },
  {
    "car_number": 5,
    "team_name": "Stallion Motorsport",
    "institution_name": "SKNCOE",
    "event_name": "Endurance",
    "lap_number": 10,
    "lap_time": 129,
    "driver_initial": "D2"
  },
  {
    "car_number": 5,
    "team_name": "Stallion Motorsport",
    "institution_name": "SKNCOE",
    "event_name": "Endurance",
    "lap_number": 11,
    "lap_time": 119,
    "driver_initial": "D2"
  },
  {
    "car_number": 5,
    "team_name": "Stallion Motorsport",
    "institution_name": "SKNCOE",
    "event_name": "Endurance",
    "lap_number": 12,
    "lap_time": 129,
    "driver_initial": "D2"
  },
  {
    "car_number": 4,
    "team_name": "DJS Racing",
    "institution_name": "DJSCE",
    "event_name": "Endurance",
    "lap_number": 1,
    "lap_time": 146,
    "driver_initial": "D1"
  },
  {
    "car_number": 4,
    "team_name": "DJS Racing",
    "institution_name": "DJSCE",
    "event_name": "Endurance",
    "lap_number": 2,
    "lap_time": 113,
    "driver_initial": "D1"
  },
  {
    "car_number": 4,
    "team_name": "DJS Racing",
    "institution_name": "DJSCE",
    "event_name": "Endurance",
    "lap_number": 3,
    "lap_time": 112,
    "driver_initial": "D1"
  },
  {
    "car_number": 4,
    "team_name": "DJS Racing",
    "institution_name": "DJSCE",
    "event_name": "Endurance",
    "lap_number": 4,
    "lap_time": 121,
    "driver_initial": "D1"
  },
  {
    "car_number": 4,
    "team_name": "DJS Racing",
    "institution_name": "DJSCE",
    "event_name": "Endurance",
    "lap_number": 5,
    "lap_time": 118,
    "driver_initial": "D1"
  },
  {
    "car_number": 4,
    "team_name": "DJS Racing",
    "institution_name": "DJSCE",
    "event_name": "Endurance",
    "lap_number": 6,
    "lap_time": 134,
    "driver_initial": "D1"
  },
  {
    "car_number": 4,
    "team_name": "DJS Racing",
    "institution_name": "DJSCE",
    "event_name": "Endurance",
    "lap_number": 7,
    "lap_time": 137,
    "driver_initial": "D1"
  },
  {
    "car_number": 4,
    "team_name": "DJS Racing",
    "institution_name": "DJSCE",
    "event_name": "Endurance",
    "lap_number": 8,
    "lap_time": 126,
    "driver_initial": "D1"
  },
  {
    "car_number": 4,
    "team_name": "DJS Racing",
    "institution_name": "DJSCE",
    "event_name": "Endurance",
    "lap_number": 9,
    "lap_time": 132,
    "driver_initial": "D1"
  },
  {
    "car_number": 4,
    "team_name": "DJS Racing",
    "institution_name": "DJSCE",
    "event_name": "Endurance",
    "lap_number": 10,
    "lap_time": 115,
    "driver_initial": "D2"
  },
  {
    "car_number": 4,
    "team_name": "DJS Racing",
    "institution_name": "DJSCE",
    "event_name": "Endurance",
    "lap_number": 11,
    "lap_time": 108,
    "driver_initial": "D2"
  },
  {
    "car_number": 4,
    "team_name": "DJS Racing",
    "institution_name": "DJSCE",
    "event_name": "Endurance",
    "lap_number": 12,
    "lap_time": 106,
    "driver_initial": "D2"
  },
  {
    "car_number": 4,
    "team_name": "DJS Racing",
    "institution_name": "DJSCE",
    "event_name": "Endurance",
    "lap_number": 13,
    "lap_time": 110,
    "driver_initial": "D2"
  },
  {
    "car_number": 4,
    "team_name": "DJS Racing",
    "institution_name": "DJSCE",
    "event_name": "Endurance",
    "lap_number": 14,
    "lap_time": 109,
    "driver_initial": "D2"
  },
  {
    "car_number": 4,
    "team_name": "DJS Racing",
    "institution_name": "DJSCE",
    "event_name": "Endurance",
    "lap_number": 15,
    "lap_time": 108,
    "driver_initial": "D2"
  },
  {
    "car_number": 4,
    "team_name": "DJS Racing",
    "institution_name": "DJSCE",
    "event_name": "Endurance",
    "lap_number": 16,
    "lap_time": 108,
    "driver_initial": "D2"
  },
  {
    "car_number": 4,
    "team_name": "DJS Racing",
    "institution_name": "DJSCE",
    "event_name": "Endurance",
    "lap_number": 17,
    "lap_time": 108,
    "driver_initial": "D2"
  },
  {
    "car_number": 4,
    "team_name": "DJS Racing",
    "institution_name": "DJSCE",
    "event_name": "Endurance",
    "lap_number": 18,
    "lap_time": 114,
    "driver_initial": "D2"
  },
  {
    "car_number": 27,
    "team_name": "Team Octane Racing",
    "institution_name": "COEP",
    "event_name": "Endurance",
    "lap_number": 1,
    "lap_time": 124,
    "driver_initial": "D1"
  },
  {
    "car_number": 27,
    "team_name": "Team Octane Racing",
    "institution_name": "COEP",
    "event_name": "Endurance",
    "lap_number": 2,
    "lap_time": 115,
    "driver_initial": "D1"
  },
  {
    "car_number": 27,
    "team_name": "Team Octane Racing",
    "institution_name": "COEP",
    "event_name": "Endurance",
    "lap_number": 3,
    "lap_time": 120,
    "driver_initial": "D1"
  },
  {
    "car_number": 27,
    "team_name": "Team Octane Racing",
    "institution_name": "COEP",
    "event_name": "Endurance",
    "lap_number": 4,
    "lap_time": 123,
    "driver_initial": "D1"
  },
  {
    "car_number": 27,
    "team_name": "Team Octane Racing",
    "institution_name": "COEP",
    "event_name": "Endurance",
    "lap_number": 5,
    "lap_time": 126,
    "driver_initial": "D1"
  },
  {
    "car_number": 27,
    "team_name": "Team Octane Racing",
    "institution_name": "COEP",
    "event_name": "Endurance",
    "lap_number": 6,
    "lap_time": 124,
    "driver_initial": "D1"
  },
  {
    "car_number": 27,
    "team_name": "Team Octane Racing",
    "institution_name": "COEP",
    "event_name": "Endurance",
    "lap_number": 7,
    "lap_time": 137,
    "driver_initial": "D1"
  },
  {
    "car_number": 27,
    "team_name": "Team Octane Racing",
    "institution_name": "COEP",
    "event_name": "Endurance",
    "lap_number": 8,
    "lap_time": 130,
    "driver_initial": "D1"
  },
  {
    "car_number": 27,
    "team_name": "Team Octane Racing",
    "institution_name": "COEP",
    "event_name": "Endurance",
    "lap_number": 9,
    "lap_time": 116,
    "driver_initial": "D1"
  },
  {
    "car_number": 27,
    "team_name": "Team Octane Racing",
    "institution_name": "COEP",
    "event_name": "Endurance",
    "lap_number": 10,
    "lap_time": 122,
    "driver_initial": "D2"
  },
  {
    "car_number": 27,
    "team_name": "Team Octane Racing",
    "institution_name": "COEP",
    "event_name": "Endurance",
    "lap_number": 11,
    "lap_time": 107,
    "driver_initial": "D2"
  },
  {
    "car_number": 27,
    "team_name": "Team Octane Racing",
    "institution_name": "COEP",
    "event_name": "Endurance",
    "lap_number": 12,
    "lap_time": 109,
    "driver_initial": "D2"
  },
  {
    "car_number": 27,
    "team_name": "Team Octane Racing",
    "institution_name": "COEP",
    "event_name": "Endurance",
    "lap_number": 13,
    "lap_time": 101,
    "driver_initial": "D2"
  },
  {
    "car_number": 27,
    "team_name": "Team Octane Racing",
    "institution_name": "COEP",
    "event_name": "Endurance",
    "lap_number": 14,
    "lap_time": 106,
    "driver_initial": "D2"
  },
  {
    "car_number": 27,
    "team_name": "Team Octane Racing",
    "institution_name": "COEP",
    "event_name": "Endurance",
    "lap_number": 15,
    "lap_time": 98,
    "driver_initial": "D2"
  },
  {
    "car_number": 27,
    "team_name": "Team Octane Racing",
    "institution_name": "COEP",
    "event_name": "Endurance",
    "lap_number": 16,
    "lap_time": 104,
    "driver_initial": "D2"
  },
  {
    "car_number": 27,
    "team_name": "Team Octane Racing",
    "institution_name": "COEP",
    "event_name": "Endurance",
    "lap_number": 17,
    "lap_time": 99,
    "driver_initial": "D2"
  },
  {
    "car_number": 27,
    "team_name": "Team Octane Racing",
    "institution_name": "COEP",
    "event_name": "Endurance",
    "lap_number": 18,
    "lap_time": 116,
    "driver_initial": "D2"
  },
  {
    "car_number": 16,
    "team_name": "GTU Motorsports",
    "institution_name": "GTU",
    "event_name": "Endurance",
    "lap_number": 1,
    "lap_time": 124,
    "driver_initial": "D1"
  },
  {
    "car_number": 16,
    "team_name": "GTU Motorsports",
    "institution_name": "GTU",
    "event_name": "Endurance",
    "lap_number": 2,
    "lap_time": 115,
    "driver_initial": "D1"
  },
  {
    "car_number": 16,
    "team_name": "GTU Motorsports",
    "institution_name": "GTU",
    "event_name": "Endurance",
    "lap_number": 3,
    "lap_time": 112,
    "driver_initial": "D1"
  },
  {
    "car_number": 16,
    "team_name": "GTU Motorsports",
    "institution_name": "GTU",
    "event_name": "Endurance",
    "lap_number": 4,
    "lap_time": 114,
    "driver_initial": "D1"
  },
  {
    "car_number": 16,
    "team_name": "GTU Motorsports",
    "institution_name": "GTU",
    "event_name": "Endurance",
    "lap_number": 5,
    "lap_time": 115,
    "driver_initial": "D1"
  },
  {
    "car_number": 16,
    "team_name": "GTU Motorsports",
    "institution_name": "GTU",
    "event_name": "Endurance",
    "lap_number": 6,
    "lap_time": 109,
    "driver_initial": "D1"
  },
  {
    "car_number": 16,
    "team_name": "GTU Motorsports",
    "institution_name": "GTU",
    "event_name": "Endurance",
    "lap_number": 7,
    "lap_time": 109,
    "driver_initial": "D1"
  },
  {
    "car_number": 16,
    "team_name": "GTU Motorsports",
    "institution_name": "GTU",
    "event_name": "Endurance",
    "lap_number": 8,
    "lap_time": 114,
    "driver_initial": "D1"
  },
  {
    "car_number": 16,
    "team_name": "GTU Motorsports",
    "institution_name": "GTU",
    "event_name": "Endurance",
    "lap_number": 9,
    "lap_time": 107,
    "driver_initial": "D1"
  },
  {
    "car_number": 16,
    "team_name": "GTU Motorsports",
    "institution_name": "GTU",
    "event_name": "Endurance",
    "lap_number": 10,
    "lap_time": 119,
    "driver_initial": "D2"
  },
  {
    "car_number": 16,
    "team_name": "GTU Motorsports",
    "institution_name": "GTU",
    "event_name": "Endurance",
    "lap_number": 11,
    "lap_time": 103,
    "driver_initial": "D2"
  },
  {
    "car_number": 16,
    "team_name": "GTU Motorsports",
    "institution_name": "GTU",
    "event_name": "Endurance",
    "lap_number": 12,
    "lap_time": 101,
    "driver_initial": "D2"
  },
  {
    "car_number": 16,
    "team_name": "GTU Motorsports",
    "institution_name": "GTU",
    "event_name": "Endurance",
    "lap_number": 13,
    "lap_time": 97,
    "driver_initial": "D2"
  },
  {
    "car_number": 16,
    "team_name": "GTU Motorsports",
    "institution_name": "GTU",
    "event_name": "Endurance",
    "lap_number": 14,
    "lap_time": 99,
    "driver_initial": "D2"
  },
  {
    "car_number": 16,
    "team_name": "GTU Motorsports",
    "institution_name": "GTU",
    "event_name": "Endurance",
    "lap_number": 15,
    "lap_time": 103,
    "driver_initial": "D2"
  },
  {
    "car_number": 16,
    "team_name": "GTU Motorsports",
    "institution_name": "GTU",
    "event_name": "Endurance",
    "lap_number": 16,
    "lap_time": 109,
    "driver_initial": "D2"
  },
  {
    "car_number": 16,
    "team_name": "GTU Motorsports",
    "institution_name": "GTU",
    "event_name": "Endurance",
    "lap_number": 17,
    "lap_time": 99,
    "driver_initial": "D2"
  },
  {
    "car_number": 16,
    "team_name": "GTU Motorsports",
    "institution_name": "GTU",
    "event_name": "Endurance",
    "lap_number": 18,
    "lap_time": 99,
    "driver_initial": "D2"
  },
  {
    "car_number": "E01",
    "team_name": "Team Kratos Racing Electric",
    "institution_name": "PCCOE",
    "event_name": "Endurance",
    "lap_number": 1,
    "lap_time": 139,
    "driver_initial": "D1"
  },
  {
    "car_number": "E01",
    "team_name": "Team Kratos Racing Electric",
    "institution_name": "PCCOE",
    "event_name": "Endurance",
    "lap_number": 2,
    "lap_time": 127,
    "driver_initial": "D1"
  },
  {
    "car_number": "E01",
    "team_name": "Team Kratos Racing Electric",
    "institution_name": "PCCOE",
    "event_name": "Endurance",
    "lap_number": 3,
    "lap_time": 122,
    "driver_initial": "D1"
  },
  {
    "car_number": "E01",
    "team_name": "Team Kratos Racing Electric",
    "institution_name": "PCCOE",
    "event_name": "Endurance",
    "lap_number": 4,
    "lap_time": 123,
    "driver_initial": "D1"
  },
  {
    "car_number": "E01",
    "team_name": "Team Kratos Racing Electric",
    "institution_name": "PCCOE",
    "event_name": "Endurance",
    "lap_number": 5,
    "lap_time": 122,
    "driver_initial": "D1"
  },
  {
    "car_number": "E01",
    "team_name": "Team Kratos Racing Electric",
    "institution_name": "PCCOE",
    "event_name": "Endurance",
    "lap_number": 6,
    "lap_time": 121,
    "driver_initial": "D1"
  },
  {
    "car_number": "E01",
    "team_name": "Team Kratos Racing Electric",
    "institution_name": "PCCOE",
    "event_name": "Endurance",
    "lap_number": 7,
    "lap_time": 118,
    "driver_initial": "D1"
  },
  {
    "car_number": "E01",
    "team_name": "Team Kratos Racing Electric",
    "institution_name": "PCCOE",
    "event_name": "Endurance",
    "lap_number": 8,
    "lap_time": 118,
    "driver_initial": "D1"
  },
  {
    "car_number": "E01",
    "team_name": "Team Kratos Racing Electric",
    "institution_name": "PCCOE",
    "event_name": "Endurance",
    "lap_number": 9,
    "lap_time": 125,
    "driver_initial": "D1"
  },
  {
    "car_number": "E01",
    "team_name": "Team Kratos Racing Electric",
    "institution_name": "PCCOE",
    "event_name": "Endurance",
    "lap_number": 10,
    "lap_time": 143,
    "driver_initial": "D2"
  },
  {
    "car_number": "E01",
    "team_name": "Team Kratos Racing Electric",
    "institution_name": "PCCOE",
    "event_name": "Endurance",
    "lap_number": 11,
    "lap_time": 120,
    "driver_initial": "D2"
  },
  {
    "car_number": "E01",
    "team_name": "Team Kratos Racing Electric",
    "institution_name": "PCCOE",
    "event_name": "Endurance",
    "lap_number": 12,
    "lap_time": 114,
    "driver_initial": "D2"
  },
  {
    "car_number": "E01",
    "team_name": "Team Kratos Racing Electric",
    "institution_name": "PCCOE",
    "event_name": "Endurance",
    "lap_number": 13,
    "lap_time": 114,
    "driver_initial": "D2"
  },
  {
    "car_number": "E01",
    "team_name": "Team Kratos Racing Electric",
    "institution_name": "PCCOE",
    "event_name": "Endurance",
    "lap_number": 14,
    "lap_time": 113,
    "driver_initial": "D2"
  },
  {
    "car_number": "E01",
    "team_name": "Team Kratos Racing Electric",
    "institution_name": "PCCOE",
    "event_name": "Endurance",
    "lap_number": 15,
    "lap_time": 113,
    "driver_initial": "D2"
  },
  {
    "car_number": "E01",
    "team_name": "Team Kratos Racing Electric",
    "institution_name": "PCCOE",
    "event_name": "Endurance",
    "lap_number": 16,
    "lap_time": 113,
    "driver_initial": "D2"
  },
  {
    "car_number": "E01",
    "team_name": "Team Kratos Racing Electric",
    "institution_name": "PCCOE",
    "event_name": "Endurance",
    "lap_number": 17,
    "lap_time": 118,
    "driver_initial": "D2"
  },
  {
    "car_number": "E01",
    "team_name": "Team Kratos Racing Electric",
    "institution_name": "PCCOE",
    "event_name": "Endurance",
    "lap_number": 18,
    "lap_time": 113,
    "driver_initial": "D2"
  }
]