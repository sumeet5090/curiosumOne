module.exports = [
  {
    "car_number": 1,
    "team_name": "Inspired Karters",
    "institution_name": "Birla Institute of Technology and Science, Pilani",
    "create": false,
    "category": "electric"
  },
  {
    "car_number": 2,
    "team_name": "PARSEC Racing",
    "institution_name": "Dayananda Sagar College of Engineering",
    "create": true,
    "category": "electric"
  },
  {
    "car_number": 3,
    "team_name": "Team Octane Racing",
    "institution_name": "College of Engineering Pune",
    "create": false,
    "category": "electric"
  },
  {
    "car_number": 4,
    "team_name": "Team Kratos Racing Electric",
    "institution_name": "Pimpri Chinchwad College of Engineering",
    "create": false,
    "category": "electric"
  },
  {
    "car_number": 5,
    "team_name": "Formula Manipal Electric",
    "institution_name": "Manipal Academy of Higher Education (formerly Manipal University)",
    "create": false,
    "category": "electric"
  },
  {
    "car_number": 6,
    "team_name": "Team VEGA",
    "institution_name": "PES University",
    "create": true,
    "category": "electric"
  },
  {
    "car_number": 7,
    "team_name": "Ashwa Racing",
    "institution_name": "R V College of Engineering",
    "create": false,
    "category": "electric"
  },
  {
    "car_number": 8,
    "team_name": "Stallion Motorsport Electric",
    "institution_name": "Smt. Kashibai Navale College of Engineering",
    "create": true,
    "category": "electric"
  },
  {
    "car_number": 9,
    "team_name": "Force Ikshvaku EV",
    "institution_name": "The National Institute of Engineering",
    "create": true,
    "category": "electric"
  },
  {
    "car_number": 10,
    "team_name": "Team Revolution",
    "institution_name": "D Y Patil School of Engineering Academy, Ambi Pune",
    "create": false,
    "category": "electric"
  },
  {
    "car_number": 11,
    "team_name": "Stier Racing",
    "institution_name": "Ramaiah Institute of Technology",
    "create": false,
    "category": "electric"
  }
]