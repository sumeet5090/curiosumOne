const WebFont = require('webfontloader')

WebFont.load({
    google: {
        families: ['Open Sans:400,500,600:latin,vietnamese', 'Oswald:400,500:latin']
    }
})