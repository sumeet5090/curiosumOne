// import Vue from 'vue';
// import { VueAuthenticate } from 'vue-authenticate';

// let vueAuth = new VueAuthenticate(Vue.prototype.$axios)
// Vue.use(vueAuth)