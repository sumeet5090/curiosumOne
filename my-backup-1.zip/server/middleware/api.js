const passport = require('passport')

const checkRole = async (req, res, next) => {
    
}

module.exports = {

}