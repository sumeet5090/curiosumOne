Array.prototype.contains = function (element) {
    return this.indexOf(element) > -1;
}